// calc.js — вкладка «Расчёт» (количество и раскрой лаг под забор) v5.8
// Зависит от: db.js (DB), utils.js (не обязателен, но использует тот же DB)
// Никакой отрисовки плана/профиля не трогает.
//
// Калитки: пользователь сам отмечает, какой пролёт трассы — калитка/ворота,
// и либо вводит список отрезков полотна вручную (произвольные длина и
// количество, свой раскрой через calcPackBins), либо импортирует готовый
// JSON из внешней программы gate_calc.html (там уже учтён пропил и
// геометрия укосин с запилами — при импорте наш раскрой не считается,
// используются готовые cutting.per_leaf/full_set_two_leaves из файла).
// Материал на полотно считается только если отрезки заданы полностью
// ИЛИ данные импортированы — иначе просто пометка «нужны размеры».

// ─── Пролёты трассы: сортировка DB.fencePosts по dist ──────────────────────
// dist в DB.fencePosts — расстояние вдоль ВСЕЙ трассы забора от опоры 1,
// непрерывное для всех участков (vertical/corner/horizontal/perpendicular),
// поэтому простая сортировка по dist даёт физически верный порядок опор
// без необходимости хранить отдельную цепочку.
function calcGetSpans() {
  var posts = DB.fencePosts.slice().sort(function(a, b) { return a.dist - b.dist; });
  var gates = DB.gates || [];
  var spans = [];
  for (var i = 0; i < posts.length - 1; i++) {
    var a = posts[i], b = posts[i + 1];
    var length = Math.round((b.dist - a.dist) * 1000) / 1000;
    var gateIdx = -1;
    for (var g = 0; g < gates.length; g++) {
      if ((gates[g].fromPost === a.n && gates[g].toPost === b.n) ||
          (gates[g].fromPost === b.n && gates[g].toPost === a.n)) { gateIdx = g; break; }
    }
    spans.push({ from: a.n, to: b.n, length: length, gateIndex: gateIdx });
  }
  return spans;
}

// Пролёты, ещё не отмеченные как калитка — доступны для выбора в форме добавления
function calcGetUngatedSpans() {
  return calcGetSpans().filter(function(s) { return s.gateIndex === -1; });
}

// ─── Смешанная упаковка: сначала расходуем то, что уже в наличии (freeLen ×
// freeQty, бесплатно — оно уже куплено), остаток — в новые заготовки для
// докупки (buyLen). First Fit Decreasing по общему пулу бинов, где все
// "бесплатные" бины идут первыми в очереди — поэтому FFD естественным
// образом сперва старается заполнить именно их, и только потом открывает
// новые "на докупку".
// extraFreeLens — необязательный массив обрезков произвольной длины (уже
// имеющихся кусков, например отходов от раскроя трассы), которые тоже
// пробуем использовать бесплатно, как и freeLen×freeQty, до того как
// открывать заготовки на докупку.
function calcPackMixed(needed, freeLen, freeQty, buyLen, extraFreeLens) {
  var items = needed.slice().sort(function(x, y) { return y - x; });
  var bins = [];
  (extraFreeLens || []).slice().sort(function(x, y) { return x - y; }).forEach(function(len) {
    bins.push({ items: [], used: 0, cap: len, free: true, fromWaste: true });
  });
  for (var i = 0; i < freeQty; i++) {
    bins.push({ items: [], used: 0, cap: freeLen, free: true });
  }
  items.forEach(function(len) {
    var placed = false;
    for (var i = 0; i < bins.length; i++) {
      if (bins[i].used + len <= bins[i].cap + 1e-9) {
        bins[i].items.push(len);
        bins[i].used += len;
        placed = true;
        break;
      }
    }
    if (!placed) {
      bins.push({ items: [len], used: len, cap: buyLen, free: false, overflow: len > buyLen + 1e-9 });
    }
  });

  var freeUsedBins = bins.filter(function(b) { return b.free && b.items.length > 0; });
  var wasteUsedBins = freeUsedBins.filter(function(b) { return b.fromWaste; });
  var buyBins = bins.filter(function(b) { return !b.free; });
  var totalNeeded = items.reduce(function(s, v) { return s + v; }, 0);
  var usedBins = freeUsedBins.concat(buyBins);
  var totalStockUsed = usedBins.reduce(function(s, b) { return s + b.cap; }, 0);

  return {
    bins: bins,
    freeLen: freeLen, freeQty: freeQty,
    freeUsedCount: freeUsedBins.length,
    freeUnusedCount: freeQty - (freeUsedBins.length - wasteUsedBins.length),
    freeUsedBins: freeUsedBins,
    wasteUsedCount: wasteUsedBins.length,
    wasteAvailableCount: (extraFreeLens || []).length,
    buyLen: buyLen,
    buyCount: buyBins.length,
    buyBins: buyBins,
    totalNeeded: Math.round(totalNeeded * 1000) / 1000,
    totalStockUsed: Math.round(totalStockUsed * 1000) / 1000,
    waste: Math.round((totalStockUsed - totalNeeded) * 1000) / 1000
  };
}

// ─── Извлечь обрезки (остатки) из уже посчитанного раскроя calcPackMixed —
// каждый использованный бин (и "в наличии", и "на докупку") оставляет
// физический кусок cap−used, который можно пустить в дело дальше.
function calcExtractOffcuts(packed) {
  var offcuts = [];
  packed.bins.forEach(function(bin) {
    if (bin.items.length === 0) return;
    var rest = Math.round((bin.cap - bin.used) * 1000) / 1000;
    if (rest > 0.001) offcuts.push(rest);
  });
  return offcuts;
}

// ─── Раскрой без учёта наличия: укладка needed[] в заготовки длиной stockLen
// (First Fit Decreasing). Начиная с v5.7 в самом расчёте не используется —
// везде применяется calcPackMixed (в наличии X / докупить Y). Оставлена как
// простая утилита на случай, если понадобится расчёт «с нуля», без деления
// на наличие/докупку.
function calcPackBins(needed, stockLen) {
  var items = needed.slice().sort(function(x, y) { return y - x; });
  var bins = [];
  items.forEach(function(len) {
    var placed = false;
    for (var i = 0; i < bins.length; i++) {
      if (bins[i].used + len <= stockLen + 1e-9) {
        bins[i].items.push(len);
        bins[i].used += len;
        placed = true;
        break;
      }
    }
    if (!placed) {
      bins.push({ items: [len], used: len, overflow: len > stockLen + 1e-9 });
    }
  });
  var totalNeeded = items.reduce(function(s, v) { return s + v; }, 0);
  var totalStock = bins.length * stockLen;
  return {
    bins: bins,
    count: bins.length,
    totalNeeded: Math.round(totalNeeded * 1000) / 1000,
    totalStock: Math.round(totalStock * 1000) / 1000,
    waste: Math.round((totalStock - totalNeeded) * 1000) / 1000
  };
}

// ─── Основной расчёт лаг по трассе (калитки исключены, как только отмечены) ─
function calcLags() {
  var cfg = DB.calcConfig;
  var levels = cfg.lagLevels;
  var spans = calcGetSpans().filter(function(s) { return s.gateIndex === -1; });

  var needed = [];
  spans.forEach(function(s) {
    for (var k = 0; k < levels; k++) needed.push(s.length);
  });

  var packed = calcPackMixed(needed, cfg.stockOnHandLength, cfg.stockOnHand, cfg.stockLength);
  return { spans: spans, levels: levels, needed: needed, packed: packed };
}

// ─── Калитки: считаются только если отрезки полотна заданы полностью,
// либо данные полностью импортированы из внешней программы ─────────────────
function calcGateIsSpecified(gate) {
  if (gate.imported) return true;
  return !!(gate.segments && gate.segments.length > 0 &&
    gate.segments.every(function(s) { return s.length > 0 && s.qty > 0; }));
}

function calcGates(offcuts) {
  var cfg = DB.calcConfig;
  var gates = DB.gates || [];
  return gates.map(function(g, idx) {
    if (g.imported) return { gate: g, index: idx, specified: true, imported: true };
    var specified = calcGateIsSpecified(g);
    if (!specified) return { gate: g, index: idx, specified: false };
    var needed = [];
    g.segments.forEach(function(s) {
      for (var k = 0; k < s.qty; k++) needed.push(s.length);
    });
    var packed = calcPackMixed(needed, cfg.leafStockOnHandLength, cfg.leafStockOnHand, cfg.leafStockLength, offcuts);
    return { gate: g, index: idx, specified: true, imported: false, needed: needed, packed: packed };
  });
}

// ─── Управление калитками (ручной ввод) ────────────────────────────────────
function calcAddGate(spanValue) {
  if (!spanValue) return;
  var parts = spanValue.split('|');
  var from = parts[0], to = parts[1];
  if (!DB.gates) DB.gates = [];
  DB.gates.push({
    fromPost: from, toPost: to,
    label: 'Калитка №' + (DB.gates.length + 1),
    type: 'kalitka',   // 'kalitka' | 'vorota' — вручную переключается, не влияет
                       // на расчёт сам по себе, только на подпись/дефолт при импорте
    segments: [],
    imported: null
  });
  calcRender();
}

function calcUpdateGateType(index, value) {
  DB.gates[index].type = value;
  calcRenderGates();
}

function calcRemoveGate(index) {
  DB.gates.splice(index, 1);
  calcRender();
}

function calcUpdateGateLabel(index, value) {
  DB.gates[index].label = value;
  // без полного calcRender — не терять фокус поля при вводе текста
}

function calcAddGateSegment(gateIndex) {
  DB.gates[gateIndex].segments.push({ length: 0, qty: 1 });
  calcRender();
}

function calcRemoveGateSegment(gateIndex, segIndex) {
  DB.gates[gateIndex].segments.splice(segIndex, 1);
  calcRender();
}

function calcUpdateGateSegment(gateIndex, segIndex, field, value) {
  var n = parseFloat(value);
  DB.gates[gateIndex].segments[segIndex][field] = isNaN(n) ? 0 : n;
  calcRenderGates(); // достаточно перерисовать только блок калиток
}

// ─── Импорт из внешней программы gate_calc.html ────────────────────────────
// Формат (мм): { type:"single"|"double", dimensions{...,stock_length_mm,
// kerf_mm}, leaf_geometry{...}, pieces_per_leaf:[{label,length_mm,qty}],
// cutting:{ per_leaf:{bars,waste_mm}, full_set_two_leaves:{bars,waste_mm} } }
function calcValidateImportedGate(obj) {
  return !!(obj && (obj.type === 'single' || obj.type === 'double') &&
    obj.dimensions && obj.pieces_per_leaf && obj.cutting &&
    obj.cutting.per_leaf && obj.cutting.full_set_two_leaves);
}

function calcHandleGateFileInput(gateIndex, inputEl) {
  var file = inputEl.files && inputEl.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    var parsed;
    try {
      parsed = JSON.parse(e.target.result);
    } catch (err) {
      alert('Не удалось прочитать JSON: ' + err.message);
      return;
    }
    if (!calcValidateImportedGate(parsed)) {
      alert('Файл не похож на экспорт gate_calc.html — не хватает ожидаемых полей (type/dimensions/pieces_per_leaf/cutting).');
      return;
    }
    DB.gates[gateIndex].imported = parsed;
    DB.gates[gateIndex].type = (parsed.type === 'double') ? 'vorota' : 'kalitka';
    calcRender();
  };
  reader.readAsText(file);
}

function calcClearGateImport(gateIndex) {
  DB.gates[gateIndex].imported = null;
  calcRender();
}

// Итоговая потребность по импортированной калитке: для 'single' — один
// комплект per_leaf (одна створка), для 'double' — full_set_two_leaves
// (обе створки сразу, вторая — зеркально, второй набор уже включён).
// Собрать список отрезков рамки полотна из импортированного JSON (мм → м),
// удвоенных для 'double' (вторая створка зеркальная, но по длинам деталей
// идентична — то же количество каждой длины).
function calcImportedGateSegments(gate) {
  var imp = gate.imported;
  var mult = (imp.type === 'double') ? 2 : 1;
  var needed = [];
  imp.pieces_per_leaf.forEach(function(p) {
    for (var k = 0; k < p.qty * mult; k++) needed.push(p.length_mm / 1000);
  });
  return needed;
}

// Потребность по импортированной калитке — считаем СВОЕЙ смешанной упаковкой
// (в наличии X / докупить Y), а не готовым cutting из файла: только так
// можно учесть остатки, которых импорт не знает. ВАЖНО: наш раскрой не
// учитывает пропил (kerf_mm) — в отличие от готового cutting в файле, где
// пропил уже заложен. Для маленьких деталей (укосины и т.п.) расхождение
// на практике небольшое, но не нулевое — оставляем это как известное
// упрощение (см. AGENT_HANDOFF.md).
function calcImportedGateNeed(gate, offcuts) {
  var imp = gate.imported;
  var cfg = DB.calcConfig;
  var needed = calcImportedGateSegments(gate);
  var buyLen = imp.dimensions.stock_length_mm / 1000;
  var packed = calcPackMixed(needed, cfg.leafStockOnHandLength, cfg.leafStockOnHand, buyLen, offcuts);
  var refCut = (imp.type === 'double') ? imp.cutting.full_set_two_leaves : imp.cutting.per_leaf;
  return {
    packed: packed,
    buyLenM: buyLen,
    kerfMm: imp.dimensions.kerf_mm,
    refBars: refCut.bars,           // для справки: сколько было бы по расчёту gate_calc.html (с пропилом), если покупать всё заново
    refWasteM: Math.round(refCut.waste_mm) / 1000
  };
}

// ─── Рендер таблицы пролётов ────────────────────────────────────────────────
function calcRenderSpansTable(spans) {
  var html = '<table class="calc-table"><thead><tr>' +
    '<th>Пролёт</th><th>Длина, м</th><th>Статус</th></tr></thead><tbody>';
  spans.forEach(function(s) {
    var isGate = s.gateIndex !== -1;
    var tag = isGate
      ? ('<span class="calc-gate-tag">⛔ ' + DB.gates[s.gateIndex].label + '</span>')
      : '<span class="calc-ok-tag">лаги</span>';
    html += '<tr' + (isGate ? ' class="calc-row-gate"' : '') + '>' +
      '<td>' + s.from + ' → ' + s.to + '</td>' +
      '<td>' + s.length.toFixed(2) + '</td>' +
      '<td>' + tag + '</td></tr>';
  });
  html += '</tbody></table>';
  return html;
}

// ─── Рендер результата смешанного раскроя (calcPackMixed) ─────────────────
function calcRenderPacked(mixed) {
  var html = '<div class="calc-summary">';
  if (mixed.wasteAvailableCount > 0) {
    html += '<div class="calc-summary-item">обрезки трассы: использовано <b>' + mixed.wasteUsedCount +
      '</b> из ' + mixed.wasteAvailableCount + '</div>';
  }
  html += '<div class="calc-summary-item">в наличии: <b>' + mixed.freeQty + '</b> шт. × ' + mixed.freeLen.toFixed(2) + ' м' +
    ' (использовано: ' + (mixed.freeUsedCount - mixed.wasteUsedCount) + ')</div>';
  if (mixed.buyCount > 0) {
    html += '<div class="calc-summary-item calc-summary-buy">докупить: <b>' + mixed.buyCount + '</b> шт. × ' + mixed.buyLen.toFixed(2) + ' м</div>';
  } else {
    html += '<div class="calc-summary-item calc-summary-ok">хватает наличия' +
      (mixed.freeUnusedCount > 0 ? ', в запасе <b>' + mixed.freeUnusedCount + '</b> шт. × ' + mixed.freeLen.toFixed(2) + ' м' : '') + '</div>';
  }
  html +=
    '<div class="calc-summary-item">итого материала: <b>' + mixed.totalNeeded.toFixed(2) + '</b> м</div>' +
    '<div class="calc-summary-item">отход: <b>' + mixed.waste.toFixed(2) + '</b> м</div>' +
    '</div>';

  html += '<div class="calc-cutlist-title">План реза:</div>';
  html += '<ol class="calc-cutlist">';
  mixed.bins.forEach(function(bin) {
    if (bin.items.length === 0) return; // неиспользованная заготовка из наличия — не показываем в раскрое
    var parts = bin.items.map(function(v) { return v.toFixed(2); }).join(' + ');
    var rest = Math.round((bin.cap - bin.used) * 1000) / 1000;
    var overflowNote = bin.overflow ? ' <span class="calc-gate-tag">⚠ длиннее заготовки!</span>' : '';
    var sourceTag = bin.fromWaste
      ? ' <span class="calc-ok-tag">(обрезок трассы, ' + bin.cap.toFixed(2) + ' м)</span>'
      : (bin.free ? ' <span class="calc-ok-tag">(из наличия)</span>' : ' <span class="calc-summary-buy" style="display:inline;padding:1px 6px">(докупить)</span>');
    html += '<li>' + parts + ' = ' + bin.used.toFixed(2) + ' м' +
      (rest > 0.001 ? ', остаток ' + rest.toFixed(2) + ' м' : '') + overflowNote + sourceTag + '</li>';
  });
  html += '</ol>';
  return html;
}

// ─── Рендер формы добавления калитки + список существующих калиток ────────
function calcRenderGates() {
  var el = document.getElementById('calcGatesResult');
  if (!el) return;

  // Обрезки от раскроя трассы — тоже годный материал для калиток, пускаем
  // их в дело до докупки новых заготовок (см. AGENT_HANDOFF.md, v5.8).
  var offcuts = calcExtractOffcuts(calcLags().packed);

  var html = '<div class="calc-block-title">Калитки</div>';
  if (offcuts.length > 0) {
    html += '<p class="calc-hint">Доступно обрезков от раскроя трассы: ' + offcuts.length +
      ' шт. (' + offcuts.map(function(o){return o.toFixed(2);}).join(', ') + ' м) — используются в первую очередь.</p>';
  }

  // Форма добавления: выбор ещё не отмеченного пролёта
  var free = calcGetUngatedSpans();
  if (free.length === 0) {
    html += '<p class="calc-hint">Все пролёты либо зашиваются лагами, либо уже отмечены как калитка.</p>';
  } else {
    html += '<div class="calc-gate-add">' +
      '<select id="calcNewGateSpan">' +
      free.map(function(s) {
        return '<option value="' + s.from + '|' + s.to + '">' + s.from + ' → ' + s.to + ' (' + s.length.toFixed(2) + ' м)</option>';
      }).join('') +
      '</select>' +
      '<button onclick="calcAddGate(document.getElementById(\'calcNewGateSpan\').value)">➕ Отметить калиткой</button>' +
      '</div>';
  }

  var gates = DB.gates || [];
  if (gates.length === 0) {
    html += '<p class="calc-hint">Калитки не отмечены — на плане пока сплошной забор, без проёмов.</p>';
  }

  var gatesResult = calcGates(offcuts);
  gatesResult.forEach(function(r) {
    var g = r.gate, idx = r.index;
    html += '<div class="calc-gate-card">';
    html += '<div class="calc-gate-card-head">' +
      '<input type="text" class="calc-gate-label" value="' + g.label + '" ' +
      'onchange="calcUpdateGateLabel(' + idx + ', this.value)"> ' +
      '<span class="calc-gate-span-tag">' + g.fromPost + ' → ' + g.toPost + '</span>' +
      '<select class="calc-gate-type" onchange="calcUpdateGateType(' + idx + ', this.value)">' +
      '<option value="kalitka"' + (g.type !== 'vorota' ? ' selected' : '') + '>Калитка</option>' +
      '<option value="vorota"' + (g.type === 'vorota' ? ' selected' : '') + '>Ворота</option>' +
      '</select>' +
      '<button class="calc-gate-del" onclick="calcRemoveGate(' + idx + ')">✕ удалить</button>' +
      '</div>';

    if (g.imported) {
      var imp = g.imported;
      var need = calcImportedGateNeed(g, offcuts);
      html += '<div class="calc-import-badge">📥 импортировано из gate_calc.html — ' +
        (imp.type === 'double' ? 'двустворчатые ворота' : 'одна створка') +
        ', заготовка на докупку ' + need.buyLenM.toFixed(2) + ' м, пропил ' + need.kerfMm + ' мм' +
        ' <button class="calc-seg-del" onclick="calcClearGateImport(' + idx + ')">✕ убрать импорт</button></div>';

      html += '<table class="calc-seg-table"><thead><tr><th>Деталь</th><th>Длина, м</th><th>Кол-во</th></tr></thead><tbody>';
      imp.pieces_per_leaf.forEach(function(p) {
        html += '<tr><td>' + p.label + '</td><td>' + (p.length_mm / 1000).toFixed(3) + '</td><td>' + p.qty + '</td></tr>';
      });
      html += '</tbody></table>';
      html += '<p class="calc-hint">Список деталей — ' + (imp.type === 'double' ? 'на 1 створку (× 2 в расчёте ниже)' : 'на 1 створку') +
        '. Раскрой ниже — наш собственный (с учётом «в наличии»), поэтому БЕЗ пропила ' + need.kerfMm + ' мм' +
        ' (в отличие от готового расчёта самого gate_calc.html: ' + need.refBars + ' шт. × ' + need.buyLenM.toFixed(2) +
        ' м, отход ' + need.refWasteM.toFixed(2) + ' м, «с нуля», пропил учтён) — расхождение на практике небольшое.</p>';

      html += calcRenderPacked(need.packed);
    } else {
      html += '<table class="calc-seg-table"><thead><tr><th>Длина, м</th><th>Кол-во</th><th></th></tr></thead><tbody>';
      (g.segments || []).forEach(function(s, si) {
        html += '<tr>' +
          '<td><input type="number" min="0" step="0.01" value="' + s.length + '" ' +
          'onchange="calcUpdateGateSegment(' + idx + ',' + si + ',\'length\',this.value)"></td>' +
          '<td><input type="number" min="0" step="1" value="' + s.qty + '" ' +
          'onchange="calcUpdateGateSegment(' + idx + ',' + si + ',\'qty\',this.value)"></td>' +
          '<td><button class="calc-seg-del" onclick="calcRemoveGateSegment(' + idx + ',' + si + ')">✕</button></td>' +
          '</tr>';
      });
      html += '</tbody></table>';
      html += '<button class="calc-seg-add" onclick="calcAddGateSegment(' + idx + ')">➕ Добавить отрезок</button> ';
      html += '<label class="calc-import-btn">📥 Импортировать JSON' +
        '<input type="file" accept=".json,application/json" style="display:none" ' +
        'onchange="calcHandleGateFileInput(' + idx + ', this)"></label>';

      if (!r.specified) {
        html += '<p class="calc-warn">⚠ Размеры полотна не заданы (или не у всех отрезков указаны длина и количество) — материал на калитку не считается.</p>';
      } else {
        html += calcRenderPacked(r.packed);
      }
    }
    html += '</div>';
  });

  el.innerHTML = html;
}

// ─── Полная перерисовка вкладки «Расчёт» ────────────────────────────────────
function calcRender() {
  var cfg = DB.calcConfig;

  var levelsInput = document.getElementById('calcLagLevels');
  var stockInput = document.getElementById('calcStockLength');
  var stockOnHandLenInput = document.getElementById('calcStockOnHandLength');
  var stockOnHandInput = document.getElementById('calcStockOnHand');
  var leafStockInput = document.getElementById('calcLeafStockLength');
  var leafStockOnHandLenInput = document.getElementById('calcLeafStockOnHandLength');
  var leafStockOnHandInput = document.getElementById('calcLeafStockOnHand');
  if (levelsInput) levelsInput.value = cfg.lagLevels;
  if (stockInput) stockInput.value = cfg.stockLength;
  if (stockOnHandLenInput) stockOnHandLenInput.value = cfg.stockOnHandLength;
  if (stockOnHandInput) stockOnHandInput.value = cfg.stockOnHand;
  if (leafStockInput) leafStockInput.value = cfg.leafStockLength;
  if (leafStockOnHandLenInput) leafStockOnHandLenInput.value = cfg.leafStockOnHandLength;
  if (leafStockOnHandInput) leafStockOnHandInput.value = cfg.leafStockOnHand;

  var spansEl = document.getElementById('calcSpansTable');
  if (spansEl) spansEl.innerHTML = calcRenderSpansTable(calcGetSpans());

  var lagResult = calcLags();
  var lagOut = document.getElementById('calcLagResult');
  if (lagOut) {
    lagOut.innerHTML =
      '<div class="calc-block-title">Лаги по трассе (' + lagResult.levels + ' уровня, калитки исключены)</div>' +
      calcRenderPacked(lagResult.packed);
  }

  calcRenderGates();
}

// ─── Обработчики полей ввода параметров расчёта ─────────────────────────────
function calcUpdateParam(field, value) {
  var n = parseFloat(value);
  var isOnHand = (field === 'stockOnHand' || field === 'leafStockOnHand');
  if (isNaN(n) || n < 0 || (!isOnHand && n <= 0)) return;
  if (field === 'lagLevels') n = Math.max(1, Math.round(n));
  if (isOnHand) n = Math.max(0, Math.round(n));
  DB.calcConfig[field] = n;
  calcRender();
}

// Перерисовать вкладку при переключении на неё (данные могли поменяться
// в редакторе опор на вкладке Профиль — dist пролётов пересчитается заново)
document.addEventListener('DOMContentLoaded', function() {
  var origSwitchTab = window.switchTab;
  if (typeof origSwitchTab === 'function') {
    window.switchTab = function(name) {
      origSwitchTab(name);
      if (name === 'calc') calcRender();
    };
  }
});
