// profile.js — построение профиля трассы газопровода
// Версия v5.8
// Зависит от: db.js (DB), utils.js (px, cx, cy, interpH, svgEl, addLabel)

var profileZoom = 1.0;
var baseProfileW = 0, baseProfileH = 0;

function setProfileZoom(z) {
  profileZoom = Math.max(0.2, Math.min(5.0, z));
  var svg = document.getElementById('profileSvg');
  if (!baseProfileW) {
    var vb = svg.getAttribute('viewBox').split(' ');
    baseProfileW = parseFloat(vb[2]);
    baseProfileH = parseFloat(vb[3]);
  }
  svg.setAttribute('width',  baseProfileW * profileZoom);
  svg.setAttribute('height', baseProfileH * profileZoom);
  document.getElementById('profileZoomInfo').textContent = profileZoom.toFixed(2).replace(/\.?0+$/, '') + '×';
}

document.querySelector('.profile-scroll').addEventListener('wheel', function(e) {
  e.preventDefault();
  var factor = e.deltaY > 0 ? -0.1 : 0.1;
  setProfileZoom(profileZoom + factor);
}, { passive: false });

(function() {
  var wrap = document.querySelector('.profile-scroll');
  var dragging = false, startX, startY, scrollLeft, scrollTop;
  wrap.addEventListener('mousedown', function(e) {
    if (e.button !== 0) return;
    dragging = true;
    startX = e.clientX; startY = e.clientY;
    scrollLeft = wrap.scrollLeft; scrollTop = wrap.scrollTop;
    wrap.style.userSelect = 'none';
  });
  window.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    wrap.scrollLeft = scrollLeft - (e.clientX - startX);
    wrap.scrollTop  = scrollTop  - (e.clientY - startY);
  });
  window.addEventListener('mouseup', function() {
    dragging = false;
    wrap.style.userSelect = '';
  });
})();

function exportProfileSVG() {
  var svg = document.getElementById('profileSvg');
  var clone = svg.cloneNode(true);
  var vb = svg.getAttribute('viewBox').split(' ');
  clone.setAttribute('width', vb[2]);
  clone.setAttribute('height', vb[3]);
  var bg = document.createElementNS('http://www.w3.org/2000/svg','rect');
  bg.setAttribute('width','100%'); bg.setAttribute('height','100%'); bg.setAttribute('fill','#ffffff');
  clone.insertBefore(bg, clone.firstChild);
  var data = new XMLSerializer().serializeToString(clone);
  var blob = new Blob([data], { type:'image/svg+xml' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'profile_gazoprovod.svg';
  a.click();
}

function toggleProfileLegend() {
  var l = document.getElementById('legendProfile');
  var b = document.getElementById('btnProfileLegend');
  if (l.style.display === 'none') { l.style.display = 'block'; b.classList.add('active'); }
  else { l.style.display = 'none'; b.classList.remove('active'); }
}

function switchTab(name) {
  document.querySelectorAll('.tab-content').forEach(function(t){ t.classList.remove('active'); });
  document.querySelectorAll('.tab-btn').forEach(function(b){ b.classList.remove('active'); });
  document.getElementById('tab-' + name).classList.add('active');
  document.querySelectorAll('.tab-btn').forEach(function(b){
    var label = name === 'plan' ? 'план' : (name === 'profile' ? 'профиль' : 'расчёт');
    if (b.textContent.toLowerCase().indexOf(label) !== -1) b.classList.add('active');
  });
  // Скрывать легенды при смене вкладки
  document.getElementById('legend').style.display = 'none';
  document.getElementById('btnLegend').classList.remove('active');
  document.getElementById('legendProfile').style.display = 'none';
  document.getElementById('btnProfileLegend').classList.remove('active');
}

// Пересобирает <select id="redLineSelect"> из window.redLineSegments.
// Подпись вычисляется из fromPost/toPost сегмента, а не берётся захардкоженной строкой,
// поэтому список всегда соответствует реальным опорам (после dbLoad/dbReset/dbUpload
// и после вставки/удаления опор в редакторе).
function renderRedLineSelect() {
  var sel = document.getElementById('redLineSelect');
  if (!sel) return;
  var segs = window.redLineSegments || {};
  var keys = Object.keys(segs);
  sel.innerHTML = keys.map(function(key) {
    var seg = segs[key];
    var label = 'Линия ' + key + ' (' + seg.fromPost + '→' + seg.toPost + ')';
    return '<option value="' + key + '">● ' + label + '</option>';
  }).join('');
  if (window.currentRedLine && segs[window.currentRedLine]) {
    sel.value = window.currentRedLine;
  } else if (keys.length) {
    window.currentRedLine = keys[0];
    sel.value = keys[0];
  }
}

function selectRedLine(key) {
  currentRedLine = key;
  var seg = redLineSegments[key];
  var lbl = document.getElementById('redLineLabel');
  if (lbl) lbl.textContent = 'Зазор от земли у опоры ' + seg.anchorPost + ':';
  var slider = document.getElementById('redLineSlider');
  if (slider) slider.value = redLineValues[key];
  var inp = document.getElementById('redLineValInput');
  if (inp) inp.value = redLineValues[key];
  if (typeof window.updateRedLine === 'function') updateRedLine(redLineValues[key]);
  else buildProfile();
}

function buildProfile() {
  baseProfileW = 0; baseProfileH = 0; // сброс при перестройке
  var profilePoints = DB.profilePoints.map(function(p){ return Object.assign({}, p); });

  // Уровень 0 = высота земли опоры №1 (точка В, h=0.25)
  var hZero = profilePoints[0].h; // h точки В = 0.25
  var hMin = Math.min.apply(null, profilePoints.map(function(p){ return p.h; }));
  var hMax = Math.max.apply(null, profilePoints.map(function(p){ return p.h; }));
  profilePoints.forEach(function(p){ p.drop = hZero - p.h; }); // понижение относительно опоры 1 (вниз = положительное)

  var maxDist = Math.max(
    profilePoints[profilePoints.length-1].dist,
    DB.fencePosts.reduce(function(mx, p) { return p.anchor === null ? Math.max(mx, p.dist) : mx; }, 0)
  ); // м — максимальный dist по трассе
  var maxDrop = hMax - hMin; // м (~1.01м)
  // Диапазон drop относительно hZero: от dropMin (может быть < 0) до dropMax
  var dropMin = hZero - hMax; // самое большое понижение (точка К выше → отрицательный drop = земля выше опоры1)
  var dropMax = hZero - hMin; // самое большое повышение (точка Е ниже → положительный drop)

  // Вертикальное преувеличение убрано — всегда реальный масштаб


  var distVJ = 18.16; // расстояние В→Ж в метрах
  var scale = 1700 / distVJ; // px/м: В→Ж занимает ровно 1700px
  var plotW = maxDist * scale; // полная ширина (З, И, К уходят вправо)
  var underground = DB.postDepthDefault; // м под землю по умолчанию (для оси)
  var aboveGround = DB.postLength - DB.postDepthDefault; // м над землёй (надземная часть опоры 1)
  // plotH = полный вертикальный диапазон земли: от самой высокой точки (dropMin<0) до самой низкой (dropMax>0)
  var plotH = (dropMax - dropMin) * scale;  // весь диапазон земли
  // underH — по максимальной глубине среди всех опор профиля
  var maxDepth = Math.max.apply(null, DB.fencePosts.map(function(p){ return p.depth || underground; }));
  var underH = maxDepth * scale;   // высота подземной части
  var poleAboveH = aboveGround * scale; // высота надземной части опоры в px

  var laserGap = 40;
  var PAD = { l:80, r:60, t: Math.ceil(poleAboveH + laserGap + 30), b:80 };

  var W = plotW + PAD.l + PAD.r;
  var H = plotH + underH + PAD.t + PAD.b;

  function gx(dist) { return PAD.l + dist * scale; }
  // gy: drop=0 (опора 1) → PAD.t + dropMax*scale (т.к. dropMax — это сколько "неба" выше опоры 1)
  function gy(drop) { return PAD.t + (dropMax - drop) * scale; }

  var svg = document.getElementById('profileSvg');
  svg.setAttribute('width', W);
  svg.setAttribute('height', H);
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
  svg.innerHTML = '';

  function txt(x, y, s, fill, size, anchor, weight) {
    var t = svgEl('text', { x:x, y:y, fill:fill||'#000', 'font-size':size||10,
      'font-family':'Courier New', 'text-anchor':anchor||'middle',
      'dominant-baseline':'middle', 'font-weight':weight||'normal' });
    t.textContent = s; svg.appendChild(t); return t;
  }

  svg.appendChild(svgEl('rect', { x:0, y:0, width:W, height:H, fill:'#fff' }));
  // Небо (над землёй)
  svg.appendChild(svgEl('rect', { x:PAD.l, y:PAD.t, width:plotW, height:plotH, fill:'#f0f8ff' }));
  // Подземная зона — НЕТ отдельного прямоугольника, земля заливается одним цветом ниже

  // Сетка горизонтальная — каждые 10 см
  var gridStep = 0.10; // м
  for (var g = dropMin; g <= dropMax + 0.01; g += gridStep) {
    var yy = gy(g);
    if (yy < PAD.t - 1 || yy > PAD.t + plotH + 1) continue;
    var isMajor = Math.abs(Math.round(g*100) % 20) < 1;
    svg.appendChild(svgEl('line', { x1:PAD.l, y1:yy, x2:PAD.l+plotW, y2:yy,
      stroke: isMajor ? '#ccc' : '#eee', 'stroke-width': isMajor ? '1' : '0.5' }));
    if (isMajor) {
      var cm = -Math.round(g*100); // знак: положительный drop = земля ниже = "-", отрицательный = "+"
      var label = (cm > 0 ? '-' : cm < 0 ? '+' : '') + Math.abs(cm) + 'см';
      txt(PAD.l-8, yy, label, '#000', 9, 'end');
    }
  }

  // Сетка вертикальная — каждые 2м (через всю высоту включая подземную зону)
  for (var d = 0; d <= maxDist; d += 2) {
    var xx = PAD.l + d * scale;
    svg.appendChild(svgEl('line', { x1:xx, y1:PAD.t, x2:xx, y2:PAD.t+plotH+underH,
      stroke:'#eee', 'stroke-width':'0.7' }));
    if (d % 4 === 0) txt(xx, PAD.t+plotH+underH+14, d+'м', '#000', 9, 'middle');
  }

  // Профиль земли — заливка до абсолютного низа SVG (единый цвет земли)
  var bottomY = H - PAD.b;
  var fillD = 'M'+PAD.l+','+bottomY;
  profilePoints.forEach(function(p){ fillD += ' L'+gx(p.dist)+','+gy(p.drop); });
  fillD += ' L'+(PAD.l+plotW)+','+bottomY+' Z';
  svg.appendChild(svgEl('path', { d:fillD, fill:'#c8a86b', opacity:'0.55' }));

  // Линия земли
  var groundPts = profilePoints.map(function(p){
    return gx(p.dist)+','+gy(p.drop);
  }).join(' ');
  svg.appendChild(svgEl('polyline', { points:groundPts, fill:'none',
    stroke:'#8B6914', 'stroke-width':'2.5', 'stroke-linejoin':'round', 'stroke-linecap':'round' }));

  // Лазерная линия
  var laserY = PAD.t - laserGap;
  svg.appendChild(svgEl('line', { x1:PAD.l, y1:laserY, x2:PAD.l+plotW, y2:laserY,
    stroke:'#2196F3', 'stroke-width':'2', 'stroke-dasharray':'10 4' }));
  // Подпись "Лазер" — фиксированно у левого края, не уезжает вправо
  txt(PAD.l+60, laserY-10, 'Лазерная линия', '#2196F3', 9, 'start', 'bold');

  // Столбы и точки
  profilePoints.forEach(function(p) {
    var x = gx(p.dist);
    var groundY = gy(p.drop);
    var poleTopY = groundY - p.h * scale;

    // Столб
    svg.appendChild(svgEl('line', { x1:x, y1:groundY, x2:x, y2:poleTopY,
      stroke:'#e94560', 'stroke-width':'2.5', 'stroke-linecap':'round' }));

    // Точка на лазерной линии
    svg.appendChild(svgEl('circle', { cx:x, cy:laserY, r:4,
      fill:'#fff', stroke:'#2196F3', 'stroke-width':'2' }));

    // Метка столба
    txt(x, laserY - 12, Math.round(p.h*100)+'см', '#2196F3', 9, 'middle', 'bold');

    // Точка на земле
    svg.appendChild(svgEl('circle', { cx:x, cy:groundY, r:4,
      fill:'#8B6914', stroke:'#fff', 'stroke-width':'1.5' }));

    // Имя точки
    txt(x, PAD.t+plotH+underH+16, p.n, '#000', 12, 'middle', 'bold');
    txt(x, PAD.t+plotH+underH+30, p.dist.toFixed(2)+'м', '#000', 9, 'middle');
  });

  // === Опоры забора на профиле — из resolvePosts() ===
  var PROFILE_EXCLUDE = { '15':true, '16':true, '3':true };
  var postCoords = resolvePosts();
  var fencePostsProfile = DB.fencePosts
    .filter(function(p) { return !PROFILE_EXCLUDE[p.n]; })
    .map(function(p) {
      var c = postCoords[p.n] || { xm: 0, ym: 0 };
      // Профиль строится вдоль трубы, поэтому расстояние опоры на нём —
      // это проекция её реальных xm/ym на трассу трубы, а не сырой dist
      // забора (v5.0 — устраняет путаницу двух разных осей "dist").
      return { n: p.n, dist: pipeDistForPoint(c.xm, c.ym), depth: p.depth };
    });

  // Опора 1: уровень земли и верх (top)
  var post1GroundY = gy(0); // drop=0 → земля опоры 1
  var post1TopY = post1GroundY - (DB.postLength - underground) * scale; // верх опоры 1
  var post1BotY = post1GroundY + underground * scale;  // низ опоры 1

  // Отрисовка опор забора
  var sortedPosts = fencePostsProfile.slice().sort(function(a,b){ return a.dist - b.dist; });

  sortedPosts.forEach(function(fp, idx) {
    var x = gx(fp.dist);
    var h_interp = interpH(fp.dist);
    var drop_interp = hZero - h_interp;
    var groundY = gy(drop_interp);
    var postTop, postBot;

    postTop = groundY - (DB.postLength - fp.depth) * scale;
    postBot = groundY + fp.depth * scale;

    // Линия столба — тёмно-коричневая
    svg.appendChild(svgEl('line', { x1:x, y1:postBot, x2:x, y2:postTop,
      stroke:'#5c3d00', 'stroke-width':'2.5', 'stroke-linecap':'round' }));

    // Точка на поверхности земли
    svg.appendChild(svgEl('circle', { cx:x, cy:groundY, r:3,
      fill:'#5c3d00', stroke:'#fff', 'stroke-width':'1.2' }));

    // Номер опоры — над верхушкой столба
    txt(x, postTop - 14, fp.n, '#5c3d00', 9, 'middle', 'bold');
    // Короткая засечка наверху опоры
    svg.appendChild(svgEl('line', { x1:x-5, y1:postTop, x2:x+5, y2:postTop,
      stroke:'#5c3d00', 'stroke-width':'1.5' }));
  });

  // Расстояния между соседними опорами — внизу посередине
  var bottomLabelY = PAD.t + plotH + underH + 48;
  for (var di = 0; di < sortedPosts.length - 1; di++) {
    var pA = sortedPosts[di], pB = sortedPosts[di + 1];
    var xA = gx(pA.dist), xB = gx(pB.dist);
    var midX = (xA + xB) / 2;
    var distM = (pB.dist - pA.dist).toFixed(2);
    // Горизонтальная линия со стрелками
    svg.appendChild(svgEl('line', { x1:xA+4, y1:bottomLabelY, x2:xB-4, y2:bottomLabelY,
      stroke:'#000', 'stroke-width':'0.8' }));
    svg.appendChild(svgEl('line', { x1:xA, y1:bottomLabelY-4, x2:xA, y2:bottomLabelY+4,
      stroke:'#000', 'stroke-width':'0.8' }));
    svg.appendChild(svgEl('line', { x1:xB, y1:bottomLabelY-4, x2:xB, y2:bottomLabelY+4,
      stroke:'#000', 'stroke-width':'0.8' }));
    txt(midX, bottomLabelY - 5, distM + 'м', '#000', 9, 'middle');
  }
  // Получить dist опоры по номеру
  function getPostDist(n) {
    var p = fencePostsProfile.filter(function(fp){ return fp.n === n; })[0];
    if (!p) { console.warn('Опора не найдена: ' + n); return 0; }
    return p.dist;
  }

  // Группа для всех красных линий и подписей
  var _redLinesGroup = svgEl('g', { id:'redLinesGroup' });
  svg.appendChild(_redLinesGroup);
  var _gapLabelsGroup = svgEl('g', { id:'gapLabelsGroup' });
  svg.appendChild(_gapLabelsGroup);

  function calcGapForSeg(dist, offsetM, segKey) {
    var seg = window.redLineSegments[segKey];
    var anchorDist = getPostDist(seg.anchorPost);
    var anchorH = interpH(anchorDist);
    return offsetM + (interpH(dist) - anchorH);
  }

  function drawAllRedLines() {
    _redLinesGroup.innerHTML = '';
    _gapLabelsGroup.innerHTML = '';

    var allMinGap = Infinity, allMaxGap = -Infinity;
    var activeMinGap = Infinity, activeMaxGap = -Infinity;

    Object.keys(window.redLineSegments).forEach(function(key) {
      var seg = window.redLineSegments[key];
      var offsetM = window.redLineValues[key] / 100;
      var anchorDist = getPostDist(seg.anchorPost);
      var anchorH = interpH(anchorDist);
      var anchorGroundY = gy(hZero - anchorH);
      var rY = anchorGroundY - offsetM * scale;
      var d1 = getPostDist(seg.fromPost);
      var d2 = getPostDist(seg.toPost);
      var x1 = gx(d1), x2 = gx(d2);
      var isActive = (key === window.currentRedLine);
      var lineColor = isActive ? '#e94560' : '#e94560';
      var lineWidth = isActive ? '2.5' : '1.5';

      // Красная линия сегмента (низ листа профнастила, 0 см)
      _redLinesGroup.appendChild(svgEl('line', {
        x1:x1, y1:rY, x2:x2, y2:rY,
        stroke:lineColor, 'stroke-width':lineWidth, 'stroke-linecap':'round',
        'stroke-dasharray': isActive ? 'none' : '6 3'
      }));

      // Нижняя перемычка (+crossbarLow, зелёная)
      var rY25 = rY - DB.crossbarLow * scale;
      _redLinesGroup.appendChild(svgEl('line', {
        x1:x1, y1:rY25, x2:x2, y2:rY25,
        stroke:'#2a7a2a', 'stroke-width':lineWidth, 'stroke-linecap':'round',
        'stroke-dasharray': isActive ? 'none' : '6 3'
      }));

      // Верхняя перемычка (+crossbarHigh, зелёная)
      var rY185 = rY - DB.crossbarHigh * scale;
      _redLinesGroup.appendChild(svgEl('line', {
        x1:x1, y1:rY185, x2:x2, y2:rY185,
        stroke:'#2a7a2a', 'stroke-width':lineWidth, 'stroke-linecap':'round',
        'stroke-dasharray': isActive ? 'none' : '6 3'
      }));

      // Верх листа профнастила (+sheetHeight, красная)
      var rYtop = rY - DB.sheetHeight * scale;
      _redLinesGroup.appendChild(svgEl('line', {
        x1:x1, y1:rYtop, x2:x2, y2:rYtop,
        stroke:lineColor, 'stroke-width':lineWidth, 'stroke-linecap':'round',
        'stroke-dasharray': isActive ? 'none' : '6 3'
      }));

      // Метка сегмента
      var midX = (x1 + x2) / 2;
      var segLbl = svgEl('text', { x:midX, y:rY - 8,
        fill:lineColor, 'font-size':'9', 'font-family':'Courier New',
        'text-anchor':'middle', 'font-weight':'bold' });
      segLbl.textContent = key;
      _redLinesGroup.appendChild(segLbl);

      // Опоры сегмента — подписи зазоров
      var segPosts = fencePostsProfile.filter(function(fp){
        return fp.dist >= d1 - 0.01 && fp.dist <= d2 + 0.01;
      }).sort(function(a,b){ return a.dist - b.dist; });

      segPosts.forEach(function(fp, i) {
        var x = gx(fp.dist);
        var gapM = calcGapForSeg(fp.dist, offsetM, key);
        var gapCm = Math.round(gapM * 100 * 10) / 10;
        var color = gapCm < 0 ? '#e94560' : gapCm < 5 ? '#e08000' : '#000';

        if (isActive) {
          if (gapM < activeMinGap) activeMinGap = gapM;
          if (gapM > activeMaxGap) activeMaxGap = gapM;
        }

        var side = (i % 2 === 0) ? 1 : -1;
        if (i === 0) side = 1;
        if (i === segPosts.length - 1) side = -1;
        var lblX = x + side * 14;
        var anchor = side > 0 ? 'start' : 'end';

        var lbl = svgEl('text', { x:lblX, y:rY - 5,
          fill: isActive ? color : '#000',
          'font-size': isActive ? '9' : '9',
          'font-family':'Courier New', 'text-anchor':anchor,
          'font-weight': isActive ? 'bold' : 'normal' });
        lbl.textContent = (gapCm >= 0 ? '+' : '') + gapCm + 'см';
        _gapLabelsGroup.appendChild(lbl);
      });

      // Газовые столбы сегмента
      profilePoints.filter(function(p){ return p.dist >= d1 - 0.01 && p.dist <= d2 + 0.01; }).forEach(function(p, i) {
        var x = gx(p.dist);
        var gapM = calcGapForSeg(p.dist, offsetM, key);
        var gapCm = Math.round(gapM * 100 * 10) / 10;
        var color = gapCm < 0 ? '#e94560' : '#e94560';

        if (isActive) {
          if (gapM < activeMinGap) activeMinGap = gapM;
          if (gapM > activeMaxGap) activeMaxGap = gapM;
        }

        var side = (i % 2 === 0) ? -1 : 1;
        var lblX = x + side * 14;
        var anchor = side > 0 ? 'start' : 'end';

        var lbl = svgEl('text', { x:lblX, y:rY + 14,
          fill: isActive ? color : '#000',
          'font-size': isActive ? '9' : '9',
          'font-family':'Courier New', 'text-anchor':anchor,
          'font-weight': isActive ? 'bold' : 'normal' });
        lbl.textContent = (gapCm >= 0 ? '+' : '') + gapCm + 'см';
        _gapLabelsGroup.appendChild(lbl);
      });
    });

    // Мин/макс для активной линии
    var minEl = document.getElementById('redLineMin');
    var maxEl = document.getElementById('redLineMax');
    var minCm = activeMinGap === Infinity ? '—' : Math.round(activeMinGap * 100 * 10) / 10;
    var maxCm = activeMaxGap === -Infinity ? '—' : Math.round(activeMaxGap * 100 * 10) / 10;
    if (minEl) { minEl.textContent = 'min ' + minCm + ' см'; minEl.style.color = Number(minCm) < 0 ? '#e94560' : '#c00'; }
    if (maxEl) maxEl.textContent = 'max ' + maxCm + ' см';
  }

  renderRedLineSelect();
  drawAllRedLines();

  window.updateRedLine = function(cm) {
    var val = Number(cm);
    if (isNaN(val)) return;
    window.redLineValues[window.currentRedLine] = val;
    // Персистим текущее значение в DB, иначе оно не попадёт в Сохранить/Скачать JSON
    DB.redLineDefaults[window.currentRedLine] = val;
    var slider = document.getElementById('redLineSlider');
    if (slider && Number(slider.value) !== val) slider.value = val;
    var inp = document.getElementById('redLineValInput');
    if (inp && document.activeElement !== inp) inp.value = val;
    drawAllRedLines();
  };

  window.selectRedLine = function(key) {
    window.currentRedLine = key;
    var seg = window.redLineSegments[key];
    var lbl = document.getElementById('redLineLabel');
    if (lbl) lbl.textContent = 'Зазор от земли у опоры ' + seg.anchorPost + ':';
    var slider = document.getElementById('redLineSlider');
    if (slider) slider.value = window.redLineValues[key];
    var inp = document.getElementById('redLineValInput');
    if (inp) inp.value = window.redLineValues[key];
    drawAllRedLines();
  };

  // Оси
  svg.appendChild(svgEl('line', { x1:PAD.l, y1:PAD.t, x2:PAD.l, y2:PAD.t+plotH+underH, stroke:'#000', 'stroke-width':'1.5' }));

  // Ось Y
  var yl = svgEl('text', { x:16, y:PAD.t+plotH/2, fill:'#000', 'font-size':'9',
    'font-family':'Courier New', 'text-anchor':'middle', 'dominant-baseline':'middle',
    transform:'rotate(-90,16,'+(PAD.t+plotH/2)+')' });
  yl.textContent = 'Понижение (см)'; svg.appendChild(yl);

  // Ось X
  txt(PAD.l+plotW/2, H-12, 'Расстояние от В (м) вдоль трассы газопровода', '#000', 10, 'middle');

  // Поворот Ж
  var xj = gx(18.16);
  svg.appendChild(svgEl('line', { x1:xj, y1:PAD.t-laserGap, x2:xj, y2:PAD.t+plotH+underH,
    stroke:'#BA7517', 'stroke-width':'1', 'stroke-dasharray':'4 3', opacity:'0.6' }));
  txt(xj+4, PAD.t+10, 'поворот Ж', '#BA7517', 9, 'start');

  // Метка 0м — уровень земли опоры 1 (точка В)
  var yGround1 = gy(0); // drop=0 → земля опоры 1
  txt(PAD.l-8, yGround1, '0м', '#8B6914', 9, 'end', 'bold');
  // Горизонтальная линия уровня 0м
  svg.appendChild(svgEl('line', { x1:PAD.l-4, y1:yGround1, x2:PAD.l+plotW, y2:yGround1,
    stroke:'#8B6914', 'stroke-width':'1', 'stroke-dasharray':'6 3', opacity:'0.5' }));

  // Метка -1.0м — фиксированная горизонталь
  var yUnderBot = gy(0) + 1.0 * scale;
  txt(PAD.l-8, yUnderBot, '-1.0м', '#8B6914', 9, 'end');
  svg.appendChild(svgEl('line', { x1:PAD.l, y1:yUnderBot, x2:PAD.l+plotW, y2:yUnderBot,
    stroke:'#8B6914', 'stroke-width':'0.8', 'stroke-dasharray':'4 4', opacity:'0.4' }));

  // Применить текущий зум
  setProfileZoom(profileZoom);
}

// ─── Параметры листа профнастила (высота листа, перемычки) ─────────────────
// По умолчанию заблокированы; разблокируются чекбоксом sheetParamsLock.
// Значения хранятся прямо в DB (DB.sheetHeight/crossbarLow/crossbarHigh),
// поэтому уже сохраняются/читаются через существующие dbSave/dbDownload и
// dbLoad/dbUpload (весь DB сериализуется в JSON целиком).
var SHEET_PARAM_INPUTS = {
  sheetHeightInput: 'sheetHeight',
  crossbarLowInput: 'crossbarLow',
  crossbarHighInput: 'crossbarHigh'
};

function toggleSheetParamsLock(unlocked) {
  Object.keys(SHEET_PARAM_INPUTS).forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.disabled = !unlocked;
  });
}

function updateSheetParam(key, value) {
  var num = parseFloat(String(value).replace(',', '.'));
  if (isNaN(num) || num < 0) return;
  DB[key] = num;
  if (typeof buildProfile === 'function') buildProfile();
}

function syncSheetParamInputs() {
  Object.keys(SHEET_PARAM_INPUTS).forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.value = DB[SHEET_PARAM_INPUTS[id]];
  });
}

// ─── Инициализация ──────────────────────────────────────────────────────────
window.redLineSegments = DB.redLineSegments;
// db.js — единственный источник истины при открытии страницы.
// Сохранённое состояние (localStorage) применяется только явно, кнопкой
// «📂 Загрузить» (см. dbLoad() в db.js) — автозагрузки при старте больше нет.
(function() {
  window.redLineSegments = DB.redLineSegments;
  window.redLineValues = Object.assign({}, DB.redLineDefaults);
  window.currentRedLine = Object.keys(DB.redLineSegments)[0] || 'A';
  if (typeof syncSheetParamInputs === 'function') syncSheetParamInputs();
  buildSVG();
  buildProfile();
})();
