# Agent Handoff — PlanPHP v4.9.0

## Статус
Редактор опор (sidebar) реализован — базовая версия (offset + depth).
Красные/зелёные линии работают (исправлено в v4.8.3).

## Что добавлено в v4.9.0
- `js/editor.js` — новый файл, sidebar с таблицей опор
- Кнопка «✏ Опоры» в toolbar профиля открывает/закрывает sidebar
- Можно менять: offset (м) и side (→/←) для не-якорных опор, depth для всех
- При изменении offset/side: немедленно пересчитываются профиль + план
- Якорные опоры (1,2,3,4) — показаны серым, не редактируются
- Глобальный зазор (redLineDefaultCm) редактируется в шапке sidebar

## Ограничения v4.9.0
- plan.js пока считает координаты опор локально (не из DB.fencePosts)
  → изменение offset влияет на профиль, но план не синхронизирован по offset
  → depth/side не влияют на план (только на профиль)
- Добавление/удаление опор — следующий этап

## Структура проекта
```
index.html          — разметка + 5 подключений
css/main.css
js/db.js            — все данные (v4.9.0)
js/utils.js         — px, cx, cy, pt, el, svgEl, addLabel, dimH, dimV, interpH
js/plan.js          — buildSVG, zoom, drag, export плана
js/profile.js       — buildProfile, zoom, drag, redlines, init
js/editor.js        — sidebar редактора опор
```

## Следующие шаги
1. Синхронизировать plan.js с DB.fencePosts (координаты из dist → xm/ym через геометрию трассы)
2. Добавление и удаление опор в редакторе
3. Хостинг: index.html + api.php + data.json на WordPress cPanel
