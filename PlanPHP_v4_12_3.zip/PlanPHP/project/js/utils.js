// utils.js — вспомогательные функции v4.12.3
// Зависит от: db.js (DB)

// ─── Координатные преобразования плана ──────────────────────────────────────
function px(m) { return m * DB.SCALE; }
function cx(m) { return DB.OX + px(m); }
function cy(m) { return DB.OY + px(m); }

// ─── Поиск точки по имени ───────────────────────────────────────────────────
function pt(name) {
  var p = DB.points.filter(function(p){ return p.n === name; })[0];
  return { px: cx(p.xm), py: cy(p.ym), xm: p.xm, ym: p.ym, n: p.n, t: p.t, h: p.h, info: p.info };
}

// ─── Создание SVG-элемента ───────────────────────────────────────────────────
// el() — для плана; svgEl() — псевдоним, используется в профиле
function el(tag, attrs) {
  var e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (var k in attrs) e.setAttribute(k, attrs[k]);
  return e;
}
function svgEl(tag, attrs) { return el(tag, attrs); }

// ─── Подпись на плане ───────────────────────────────────────────────────────
function addLabel(svg, lx, ly, text, fill, size) {
  var t = el('text', { x:lx, y:ly, 'text-anchor':'middle', fill:fill||'#000', 'font-size':size||9, 'font-family':'Courier New' });
  t.textContent = text; svg.appendChild(t);
}

// ─── Размерные линии плана ───────────────────────────────────────────────────
function dimH(svg, x1, x2, y, text, col) {
  col = col || '#000';
  svg.appendChild(el('line', { x1:x1, y1:y, x2:x2, y2:y, stroke:col, 'stroke-width':'0.8' }));
  svg.appendChild(el('line', { x1:x1, y1:y-3, x2:x1, y2:y+3, stroke:col, 'stroke-width':'0.8' }));
  svg.appendChild(el('line', { x1:x2, y1:y-3, x2:x2, y2:y+3, stroke:col, 'stroke-width':'0.8' }));
  addLabel(svg, (x1+x2)/2, y-5, text, col, 9);
}

function dimV(svg, x, y1, y2, text) {
  var col = '#000';
  svg.appendChild(el('line', { x1:x, y1:y1, x2:x, y2:y2, stroke:col, 'stroke-width':'0.8' }));
  svg.appendChild(el('line', { x1:x-3, y1:y1, x2:x+3, y2:y1, stroke:col, 'stroke-width':'0.8' }));
  svg.appendChild(el('line', { x1:x-3, y1:y2, x2:x+3, y2:y2, stroke:col, 'stroke-width':'0.8' }));
  var t = el('text', { x:x-5, y:(y1+y2)/2, 'text-anchor':'end', 'dominant-baseline':'middle', fill:col, 'font-size':'9', 'font-family':'Courier New' });
  t.textContent = text; svg.appendChild(t);
}

// ─── Вычисление координат всех опор из DB.fencePosts ───────────────────────
// Возвращает map: n → { xm, ym, dist }
// dist берётся напрямую из DB. Координаты xm/ym вычисляются по геометрии трассы.
function resolvePosts() {
  var FO = DB.FENCE_OFFSET;
  var rXm = DB.points.filter(function(p){ return p.n === 'Р'; })[0].xm;
  var fenceLineYm = 18.16 + FO;
  var fenceLineXm = 0.17 - FO;

  var coords = {};

  DB.fencePosts.forEach(function(p) {
    var xm, ym;
    var dist = p.dist;

    if (p.side_fence === 'vertical') {
      xm = fenceLineXm;
      ym = FO + dist;
    } else if (p.side_fence === 'corner') {
      xm = fenceLineXm;
      ym = fenceLineYm;
    } else if (p.side_fence === 'horizontal') {
      xm = fenceLineXm + (dist - 18.16);
      ym = fenceLineYm;
    } else { // perpendicular
      xm = rXm;
      ym = fenceLineYm - (dist - 33.09);
    }

    coords[p.n] = { xm: xm, ym: ym, dist: dist };
  });

  return coords;
}

// ─── Интерполяция высоты рельефа по расстоянию ──────────────────────────────
// Критическая функция — от неё зависят все расчёты профиля и красных линий
function interpH(dist) {
  var pp = DB.profilePoints;
  if (dist <= pp[0].dist) return pp[0].h;
  if (dist >= pp[pp.length-1].dist) return pp[pp.length-1].h;
  for (var k = 0; k < pp.length - 1; k++) {
    var a = pp[k], b = pp[k+1];
    if (dist >= a.dist && dist <= b.dist) {
      var t = (dist - a.dist) / (b.dist - a.dist);
      return a.h + t * (b.h - a.h);
    }
  }
  return pp[0].h;
}
