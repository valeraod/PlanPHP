// db.js — единственный источник данных проекта
// Версия v5.0
// Никакой логики — только данные.

var DB = {

  // ─── Масштаб и отступы плана ────────────────────────────────────────────
  SCALE: 30,
  OX: 90,
  OY: 60,

  // ─── Константы забора ───────────────────────────────────────────────────
  FENCE_OFFSET: 0.4,      // смещение линии забора от трубы (м)
  FENCE_STEP: 3.0,        // шаг опор вертикальной стороны (м)
  FENCE_STEP_RIGHT: 3.0,  // шаг опор горизонтальной стороны (м)

  // ─── Параметры опор ─────────────────────────────────────────────────────
  postLength: 3.0,         // длина опоры (м)
  postDepthDefault: 1.0,   // глубина вкапывания по умолчанию (м)

  // ─── Параметры листа профнастила ────────────────────────────────────────
  sheetHeight: 2.00,       // высота листа (м)
  crossbarLow: 0.25,       // нижняя перемычка от низа листа (м)
  crossbarHigh: 1.75,      // верхняя перемычка от низа листа (м)

  // ─── Дефолтный зазор красной линии ─────────────────────────────────────
  redLineDefaultCm: 15,    // см

  // ─── Точки трассы ───────────────────────────────────────────────────────
  points: [
    { n:'А', xm:0,                       ym:0,        t:'post_a',     h:'2,0м', info:'Столб металл. 60×60, h=2,0м' },
    { n:'В', xm:0.17,                    ym:0,        t:'simple',     h:'',     info:'Точка на стене' },
    { n:'Б', xm:7.92,                    ym:0,        t:'wall_corner',h:'',     info:'Конец каменной стены' },
    { n:'Г', xm:0.17,                    ym:4.89,     t:'post',       h:'2,2м', info:'Столб газ. трубы 60×60, h=2,2м' },
    { n:'Д', xm:0.17,                    ym:10.99,    t:'post',       h:'2,2м', info:'Столб газ. трубы 60×60, h=2,2м' },
    { n:'Е', xm:0.17,                    ym:17.16,    t:'post',       h:'2,2м', info:'Столб газ. трубы 60×60, h=2,2м' },
    { n:'Ж', xm:0.17,                    ym:18.16,    t:'simple',     h:'',     info:'Точка поворота трубы' },
    { n:'З', xm:0.17+3.66,               ym:18.16,    t:'post',       h:'2,2м', info:'Столб газ. трубы 60×60, h=2,2м' },
    { n:'И', xm:0.17+3.66+6.31,          ym:18.16,    t:'post',       h:'2,2м', info:'Столб газ. трубы 60×60, h=2,2м' },
    { n:'К', xm:0.17+3.66+6.31+6.54,     ym:18.16,    t:'post',       h:'2,2м', info:'Столб газ. трубы 60×60, h=2,2м' },
    { n:'Л', xm:7.92,                    ym:9.7,      t:'wall_corner',h:'',     info:'Угол стены дома' },
    { n:'М', xm:7.92-1.58,               ym:9.7,      t:'wall_corner',h:'',     info:'Угол стены дома' },
    { n:'Н', xm:7.92-1.58,               ym:9.7+5.14, t:'wall_corner',h:'',     info:'Угол стены дома' },
    { n:'О', xm:7.92-1.58+3.83,          ym:9.7+5.14, t:'entry',      h:'',     info:'Начало входа' },
    { n:'П', xm:7.92-1.58+6.10,          ym:9.7+5.14, t:'entry',      h:'',     info:'Конец входа (2,3м)' },
    { n:'Р', xm:7.92-1.58+8.36,          ym:9.7+5.14, t:'wall_corner',h:'',     info:'Угол стены → далее' }
  ],

  // ─── Профиль рельефа ────────────────────────────────────────────────────
  // dist — расстояние по трассе забора от опоры 1 (м)
  // h    — высота лазерной метки над землёй (м)
  profilePoints: [
    { n:'В', dist:0,     h:0.25 },
    { n:'Г', dist:4.89,  h:0.27 },
    { n:'Д', dist:10.99, h:0.32 },
    { n:'Е', dist:17.16, h:0.17 },
    { n:'Ж', dist:18.16, h:0.39 },
    { n:'З', dist:21.82, h:0.40 },
    { n:'И', dist:28.13, h:0.88 },
    { n:'К', dist:34.67, h:1.18 }
  ],

  // ─── Опоры забора ───────────────────────────────────────────────────────
  // dist      — расстояние от опоры 1 вдоль трассы забора (м), абсолютное
  // fixed     — true: позиция неизменна (только depth), false: можно двигать
  // depth     — глубина вкапывания (м)
  // side_fence — участок трассы: vertical / corner / horizontal / perpendicular
  fencePosts: [
    // ── Фиксированные ───────────────────────────────────────────────────
    { n:'1',  dist:0,     fixed:true,  depth:1.0, side_fence:'vertical',      info:'Опора 1 — начало трассы' },
    { n:'2',  dist:18.16, fixed:true,  depth:1.0, side_fence:'corner',        info:'Опора 2 — угловая' },
    { n:'3',  dist:36.61, fixed:true,  depth:1.0, side_fence:'perpendicular', info:'Опора 3 — перпендикуляр из Р' },
    { n:'4',  dist:33.09, fixed:true,  depth:1.0, side_fence:'horizontal',    info:'Опора 4 — конец трассы' },

    // ── Вертикальная сторона: 1→13→12→11→10→9→2 ────────────────────────
    { n:'13', dist:3.16,  fixed:false, depth:1.0, side_fence:'vertical',   info:'Опора 13' },
    { n:'12', dist:6.16,  fixed:false, depth:1.0, side_fence:'vertical',   info:'Опора 12' },
    { n:'11', dist:9.16,  fixed:false, depth:1.0, side_fence:'vertical',   info:'Опора 11' },
    { n:'10', dist:12.16, fixed:false, depth:1.0, side_fence:'vertical',   info:'Опора 10' },
    { n:'9',  dist:15.16, fixed:false, depth:1.0, side_fence:'vertical',   info:'Опора 9' },

    // ── Горизонтальная сторона: 2→5→6→17→7→8→4 ─────────────────────────
    { n:'5',  dist:21.16, fixed:false, depth:1.0, side_fence:'horizontal', info:'Опора 5' },
    { n:'6',  dist:24.16, fixed:false, depth:1.0, side_fence:'horizontal', info:'Опора 6' },
    { n:'17', dist:26.16, fixed:false, depth:1.0, side_fence:'horizontal', info:'Опора 17 — между 6 и 7' },
    { n:'7',  dist:27.16, fixed:false, depth:1.0, side_fence:'horizontal', info:'Опора 7' },
    { n:'8',  dist:30.16, fixed:false, depth:1.0, side_fence:'horizontal', info:'Опора 8' },

    // ── Перпендикуляр из Р ───────────────────────────────────────────────
    { n:'15', dist:35.11, fixed:false, depth:1.0, side_fence:'perpendicular', info:'Опора 15' },
    { n:'16', dist:36.11, fixed:false, depth:1.0, side_fence:'perpendicular', info:'Опора 16' }
  ],

  // ─── Сегменты красных линий ─────────────────────────────────────────────
  redLineSegments: {
    'A': { label:'Линия A (1→13)',  anchorPost:'1',  fromPost:'1',  toPost:'13' },
    'B': { label:'Линия B (13→12)',anchorPost:'13', fromPost:'13', toPost:'12' },
    'C': { label:'Линия C (12→11)',anchorPost:'12', fromPost:'12', toPost:'11' },
    'D': { label:'Линия D (11→10)',anchorPost:'11', fromPost:'11', toPost:'10' },
    'E': { label:'Линия E (10→9)', anchorPost:'10', fromPost:'10', toPost:'9'  },
    'F': { label:'Линия F (9→2)',  anchorPost:'9',  fromPost:'9',  toPost:'2'  },
    'G': { label:'Линия G (2→5)',  anchorPost:'2',  fromPost:'2',  toPost:'5'  },
    'H': { label:'Линия H (5→6)',  anchorPost:'5',  fromPost:'5',  toPost:'6'  },
    'I': { label:'Линия I (6→17)',anchorPost:'6',  fromPost:'6',  toPost:'17' },
    'J': { label:'Линия J (17→7)',anchorPost:'17', fromPost:'17', toPost:'7'  },
    'K': { label:'Линия K (7→8)',  anchorPost:'7',  fromPost:'7',  toPost:'8'  },
    'L': { label:'Линия L (8→4)',  anchorPost:'8',  fromPost:'8',  toPost:'4'  }
  },

  redLineDefaults: {
    'A':15,'B':15,'C':15,'D':15,'E':15,'F':15,
    'G':15,'H':15,'I':15,'J':15,'K':15,'L':15
  }

};

// ─── Снимок исходного состояния для Сброса ──────────────────────────────────
var DB_INITIAL = JSON.parse(JSON.stringify(DB));

var DB_STORAGE_KEY = 'planphp_db';

function dbSave() {
  try {
    localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(DB));
    dbStatus('✅ Сохранено', '#2a7a2a');
  } catch(e) {
    dbStatus('❌ Ошибка сохранения', '#c0392b');
  }
}

function dbLoad() {
  try {
    var raw = localStorage.getItem(DB_STORAGE_KEY);
    if (!raw) { dbStatus('⚠ Нет сохранённых данных', '#e08000'); return; }
    var saved = JSON.parse(raw);
    Object.assign(DB, saved);
    // Синхронизировать window.redLineSegments и window.redLineValues
    window.redLineSegments = DB.redLineSegments;
    window.redLineValues = {};
    Object.keys(DB.redLineDefaults).forEach(function(k){
      window.redLineValues[k] = DB.redLineDefaults[k];
    });
    window.currentRedLine = Object.keys(DB.redLineSegments)[0] || 'A';
    if (typeof syncSheetParamInputs === 'function') syncSheetParamInputs();
    if (typeof toggleSheetParamsLock === 'function') toggleSheetParamsLock(false);
    var lockCb = document.getElementById('sheetParamsLock');
    if (lockCb) lockCb.checked = false;
    if (typeof buildSVG === 'function') buildSVG();
    if (typeof buildProfile === 'function') buildProfile();
    dbStatus('✅ Загружено', '#2a7a2a');
  } catch(e) {
    dbStatus('❌ Ошибка загрузки', '#c0392b');
  }
}

function dbReset() {
  if (!confirm('Сбросить все изменения к исходному состоянию?')) return;
  Object.assign(DB, JSON.parse(JSON.stringify(DB_INITIAL)));
  window.redLineSegments = DB.redLineSegments;
  window.redLineValues = {};
  Object.keys(DB.redLineDefaults).forEach(function(k){
    window.redLineValues[k] = DB.redLineDefaults[k];
  });
  window.currentRedLine = Object.keys(DB.redLineSegments)[0] || 'A';
  if (typeof syncSheetParamInputs === 'function') syncSheetParamInputs();
  if (typeof toggleSheetParamsLock === 'function') toggleSheetParamsLock(false);
  var lockCbReset = document.getElementById('sheetParamsLock');
  if (lockCbReset) lockCbReset.checked = false;
  if (typeof buildSVG === 'function') buildSVG();
  if (typeof buildProfile === 'function') buildProfile();
  dbStatus('↩ Сброшено', '#555');
}

function dbDownload() {
  try {
    var json = JSON.stringify(DB, null, 2);
    var blob = new Blob([json], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'planphp_db.json';
    a.click();
    URL.revokeObjectURL(url);
    dbStatus('✅ Файл скачан', '#2a7a2a');
  } catch(e) {
    dbStatus('❌ Ошибка', '#c0392b');
  }
}

function dbUpload(event) {
  var file = event.target.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    try {
      var saved = JSON.parse(e.target.result);
      Object.assign(DB, saved);
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(DB));
      window.redLineSegments = DB.redLineSegments;
      window.redLineValues = {};
      Object.keys(DB.redLineDefaults).forEach(function(k){
        window.redLineValues[k] = DB.redLineDefaults[k];
      });
      window.currentRedLine = Object.keys(DB.redLineSegments)[0] || 'A';
      if (typeof syncSheetParamInputs === 'function') syncSheetParamInputs();
      if (typeof toggleSheetParamsLock === 'function') toggleSheetParamsLock(false);
      var lockCbUp = document.getElementById('sheetParamsLock');
      if (lockCbUp) lockCbUp.checked = false;
      if (typeof buildSVG === 'function') buildSVG();
      if (typeof buildProfile === 'function') buildProfile();
      dbStatus('✅ Загружено из файла', '#2a7a2a');
    } catch(e) {
      dbStatus('❌ Ошибка чтения файла', '#c0392b');
    }
  };
  reader.readAsText(file);
  event.target.value = '';
}

function dbStatus(msg, color) {
  var el = document.getElementById('dbStatus');
  if (!el) return;
  el.textContent = msg;
  el.style.color = color || '#333';
  setTimeout(function(){ el.textContent = ''; }, 3000);
}
