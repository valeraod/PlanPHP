// calc.js — вкладка «Расчёт» (количество и раскрой лаг под забор) v5.6
// Зависит от: db.js (DB), utils.js (не обязателен, но использует тот же DB)
// Никакой отрисовки плана/профиля не трогает.
//
// Калитки: пользователь сам отмечает, какой пролёт трассы — калитка/ворота,
// и либо вводит список отрезков полотна вручную (произвольные длина и
// количество, свой раскрой через calcPackBins), либо импортирует готовый
// JSON из внешней программы gate_calc.html (там уже учтён пропил и
// геометрия укосин с запилами — при импорте наш раскрой не считается,
// используются готовые cutting.per_leaf/full_set_two_leaves из файла).
// Материал на полотно считается только если отрезки заданы полностью
// ИЛИ данные импортированы — иначе просто пометка «нужны размеры».

// ─── Пролёты трассы: сортировка DB.fencePosts по dist ──────────────────────
// dist в DB.fencePosts — расстояние вдоль ВСЕЙ трассы забора от опоры 1,
// непрерывное для всех участков (vertical/corner/horizontal/perpendicular),
// поэтому простая сортировка по dist даёт физически верный порядок опор
// без необходимости хранить отдельную цепочку.
function calcGetSpans() {
  var posts = DB.fencePosts.slice().sort(function(a, b) { return a.dist - b.dist; });
  var gates = DB.gates || [];
  var spans = [];
  for (var i = 0; i < posts.length - 1; i++) {
    var a = posts[i], b = posts[i + 1];
    var length = Math.round((b.dist - a.dist) * 1000) / 1000;
    var gateIdx = -1;
    for (var g = 0; g < gates.length; g++) {
      if ((gates[g].fromPost === a.n && gates[g].toPost === b.n) ||
          (gates[g].fromPost === b.n && gates[g].toPost === a.n)) { gateIdx = g; break; }
    }
    spans.push({ from: a.n, to: b.n, length: length, gateIndex: gateIdx });
  }
  return spans;
}

// Пролёты, ещё не отмеченные как калитка — доступны для выбора в форме добавления
function calcGetUngatedSpans() {
  return calcGetSpans().filter(function(s) { return s.gateIndex === -1; });
}

// ─── Раскрой: укладка отрезков needed[] в заготовки длиной stockLen ────────
// First Fit Decreasing: сортировка по убыванию, каждый отрезок — в первую
// заготовку, где он помещается, иначе — новая заготовка.
function calcPackBins(needed, stockLen) {
  var items = needed.slice().sort(function(x, y) { return y - x; });
  var bins = [];
  items.forEach(function(len) {
    var placed = false;
    for (var i = 0; i < bins.length; i++) {
      if (bins[i].used + len <= stockLen + 1e-9) {
        bins[i].items.push(len);
        bins[i].used += len;
        placed = true;
        break;
      }
    }
    if (!placed) {
      bins.push({ items: [len], used: len, overflow: len > stockLen + 1e-9 });
    }
  });
  var totalNeeded = items.reduce(function(s, v) { return s + v; }, 0);
  var totalStock = bins.length * stockLen;
  return {
    bins: bins,
    count: bins.length,
    totalNeeded: Math.round(totalNeeded * 1000) / 1000,
    totalStock: Math.round(totalStock * 1000) / 1000,
    waste: Math.round((totalStock - totalNeeded) * 1000) / 1000
  };
}

// ─── Основной расчёт лаг по трассе (калитки исключены, как только отмечены) ─
function calcLags() {
  var cfg = DB.calcConfig;
  var levels = cfg.lagLevels;
  var stockLen = cfg.stockLength;
  var spans = calcGetSpans().filter(function(s) { return s.gateIndex === -1; });

  var needed = [];
  spans.forEach(function(s) {
    for (var k = 0; k < levels; k++) needed.push(s.length);
  });

  var packed = calcPackBins(needed, stockLen);
  return { spans: spans, levels: levels, stockLen: stockLen, needed: needed, packed: packed };
}

// ─── Калитки: считаются только если отрезки полотна заданы полностью,
// либо данные полностью импортированы из внешней программы ─────────────────
function calcGateIsSpecified(gate) {
  if (gate.imported) return true;
  return !!(gate.segments && gate.segments.length > 0 &&
    gate.segments.every(function(s) { return s.length > 0 && s.qty > 0; }));
}

function calcGates() {
  var cfg = DB.calcConfig;
  var stockLen = cfg.leafStockLength;
  var gates = DB.gates || [];
  return gates.map(function(g, idx) {
    if (g.imported) return { gate: g, index: idx, specified: true, imported: true };
    var specified = calcGateIsSpecified(g);
    if (!specified) return { gate: g, index: idx, specified: false };
    var needed = [];
    g.segments.forEach(function(s) {
      for (var k = 0; k < s.qty; k++) needed.push(s.length);
    });
    var packed = calcPackBins(needed, stockLen);
    return { gate: g, index: idx, specified: true, imported: false, needed: needed, packed: packed, stockLen: stockLen };
  });
}

// ─── Управление калитками (ручной ввод) ────────────────────────────────────
function calcAddGate(spanValue) {
  if (!spanValue) return;
  var parts = spanValue.split('|');
  var from = parts[0], to = parts[1];
  if (!DB.gates) DB.gates = [];
  DB.gates.push({
    fromPost: from, toPost: to,
    label: 'Калитка №' + (DB.gates.length + 1),
    type: 'kalitka',   // 'kalitka' | 'vorota' — вручную переключается, не влияет
                       // на расчёт сам по себе, только на подпись/дефолт при импорте
    segments: [],
    imported: null
  });
  calcRender();
}

function calcUpdateGateType(index, value) {
  DB.gates[index].type = value;
  calcRenderGates();
}

function calcRemoveGate(index) {
  DB.gates.splice(index, 1);
  calcRender();
}

function calcUpdateGateLabel(index, value) {
  DB.gates[index].label = value;
  // без полного calcRender — не терять фокус поля при вводе текста
}

function calcAddGateSegment(gateIndex) {
  DB.gates[gateIndex].segments.push({ length: 0, qty: 1 });
  calcRender();
}

function calcRemoveGateSegment(gateIndex, segIndex) {
  DB.gates[gateIndex].segments.splice(segIndex, 1);
  calcRender();
}

function calcUpdateGateSegment(gateIndex, segIndex, field, value) {
  var n = parseFloat(value);
  DB.gates[gateIndex].segments[segIndex][field] = isNaN(n) ? 0 : n;
  calcRenderGates(); // достаточно перерисовать только блок калиток
}

// ─── Импорт из внешней программы gate_calc.html ────────────────────────────
// Формат (мм): { type:"single"|"double", dimensions{...,stock_length_mm,
// kerf_mm}, leaf_geometry{...}, pieces_per_leaf:[{label,length_mm,qty}],
// cutting:{ per_leaf:{bars,waste_mm}, full_set_two_leaves:{bars,waste_mm} } }
function calcValidateImportedGate(obj) {
  return !!(obj && (obj.type === 'single' || obj.type === 'double') &&
    obj.dimensions && obj.pieces_per_leaf && obj.cutting &&
    obj.cutting.per_leaf && obj.cutting.full_set_two_leaves);
}

function calcHandleGateFileInput(gateIndex, inputEl) {
  var file = inputEl.files && inputEl.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    var parsed;
    try {
      parsed = JSON.parse(e.target.result);
    } catch (err) {
      alert('Не удалось прочитать JSON: ' + err.message);
      return;
    }
    if (!calcValidateImportedGate(parsed)) {
      alert('Файл не похож на экспорт gate_calc.html — не хватает ожидаемых полей (type/dimensions/pieces_per_leaf/cutting).');
      return;
    }
    DB.gates[gateIndex].imported = parsed;
    DB.gates[gateIndex].type = (parsed.type === 'double') ? 'vorota' : 'kalitka';
    calcRender();
  };
  reader.readAsText(file);
}

function calcClearGateImport(gateIndex) {
  DB.gates[gateIndex].imported = null;
  calcRender();
}

// Итоговая потребность по импортированной калитке: для 'single' — один
// комплект per_leaf (одна створка), для 'double' — full_set_two_leaves
// (обе створки сразу, вторая — зеркально, второй набор уже включён).
function calcImportedGateNeed(gate) {
  var imp = gate.imported;
  var cut = (imp.type === 'double') ? imp.cutting.full_set_two_leaves : imp.cutting.per_leaf;
  return {
    bars: cut.bars,
    wasteM: Math.round(cut.waste_mm) / 1000,
    stockLenM: imp.dimensions.stock_length_mm / 1000,
    kerfMm: imp.dimensions.kerf_mm
  };
}

// ─── Рендер таблицы пролётов ────────────────────────────────────────────────
function calcRenderSpansTable(spans) {
  var html = '<table class="calc-table"><thead><tr>' +
    '<th>Пролёт</th><th>Длина, м</th><th>Статус</th></tr></thead><tbody>';
  spans.forEach(function(s) {
    var isGate = s.gateIndex !== -1;
    var tag = isGate
      ? ('<span class="calc-gate-tag">⛔ ' + DB.gates[s.gateIndex].label + '</span>')
      : '<span class="calc-ok-tag">лаги</span>';
    html += '<tr' + (isGate ? ' class="calc-row-gate"' : '') + '>' +
      '<td>' + s.from + ' → ' + s.to + '</td>' +
      '<td>' + s.length.toFixed(2) + '</td>' +
      '<td>' + tag + '</td></tr>';
  });
  html += '</tbody></table>';
  return html;
}

// ─── Рендер результата раскроя ──────────────────────────────────────────────
// onHand — сколько заготовок такой длины уже есть в наличии (шт., ввод
// пользователя). Если 0 (по умолчанию) — блок "докупить" не показывается,
// только сама потребность (обратная совместимость с версией без поля).
function calcRenderPacked(packed, stockLen, onHand) {
  onHand = onHand || 0;
  var toBuy = Math.max(0, packed.count - onHand);
  var spare = Math.max(0, onHand - packed.count);

  var html = '<div class="calc-summary">' +
    '<div class="calc-summary-item">нужно: <b>' + packed.count + '</b> шт. × ' + stockLen.toFixed(2) + ' м</div>' +
    '<div class="calc-summary-item">в наличии: <b>' + onHand + '</b> шт.</div>';
  if (toBuy > 0) {
    html += '<div class="calc-summary-item calc-summary-buy">докупить: <b>' + toBuy + '</b> шт.</div>';
  } else {
    html += '<div class="calc-summary-item calc-summary-ok">хватает' + (spare > 0 ? ', в запасе <b>' + spare + '</b> шт.' : '') + '</div>';
  }
  html +=
    '<div class="calc-summary-item">итого материала: <b>' + packed.totalNeeded.toFixed(2) + '</b> м</div>' +
    '<div class="calc-summary-item">отход: <b>' + packed.waste.toFixed(2) + '</b> м</div>' +
    '</div>';

  html += '<div class="calc-cutlist-title">План реза:</div>';
  html += '<ol class="calc-cutlist">';
  packed.bins.forEach(function(bin) {
    var parts = bin.items.map(function(v) { return v.toFixed(2); }).join(' + ');
    var rest = Math.round((stockLen - bin.used) * 1000) / 1000;
    var overflowNote = bin.overflow ? ' <span class="calc-gate-tag">⚠ длиннее заготовки!</span>' : '';
    html += '<li>' + parts + ' = ' + bin.used.toFixed(2) + ' м' +
      (rest > 0.001 ? ', остаток ' + rest.toFixed(2) + ' м' : '') + overflowNote + '</li>';
  });
  html += '</ol>';
  return html;
}

// ─── Рендер формы добавления калитки + список существующих калиток ────────
function calcRenderGates() {
  var el = document.getElementById('calcGatesResult');
  if (!el) return;

  var html = '<div class="calc-block-title">Калитки</div>';

  // Форма добавления: выбор ещё не отмеченного пролёта
  var free = calcGetUngatedSpans();
  if (free.length === 0) {
    html += '<p class="calc-hint">Все пролёты либо зашиваются лагами, либо уже отмечены как калитка.</p>';
  } else {
    html += '<div class="calc-gate-add">' +
      '<select id="calcNewGateSpan">' +
      free.map(function(s) {
        return '<option value="' + s.from + '|' + s.to + '">' + s.from + ' → ' + s.to + ' (' + s.length.toFixed(2) + ' м)</option>';
      }).join('') +
      '</select>' +
      '<button onclick="calcAddGate(document.getElementById(\'calcNewGateSpan\').value)">➕ Отметить калиткой</button>' +
      '</div>';
  }

  var gates = DB.gates || [];
  if (gates.length === 0) {
    html += '<p class="calc-hint">Калитки не отмечены — на плане пока сплошной забор, без проёмов.</p>';
  }

  var gatesResult = calcGates();
  gatesResult.forEach(function(r) {
    var g = r.gate, idx = r.index;
    html += '<div class="calc-gate-card">';
    html += '<div class="calc-gate-card-head">' +
      '<input type="text" class="calc-gate-label" value="' + g.label + '" ' +
      'onchange="calcUpdateGateLabel(' + idx + ', this.value)"> ' +
      '<span class="calc-gate-span-tag">' + g.fromPost + ' → ' + g.toPost + '</span>' +
      '<select class="calc-gate-type" onchange="calcUpdateGateType(' + idx + ', this.value)">' +
      '<option value="kalitka"' + (g.type !== 'vorota' ? ' selected' : '') + '>Калитка</option>' +
      '<option value="vorota"' + (g.type === 'vorota' ? ' selected' : '') + '>Ворота</option>' +
      '</select>' +
      '<button class="calc-gate-del" onclick="calcRemoveGate(' + idx + ')">✕ удалить</button>' +
      '</div>';

    if (g.imported) {
      var imp = g.imported;
      var need = calcImportedGateNeed(g);
      html += '<div class="calc-import-badge">📥 импортировано из gate_calc.html — ' +
        (imp.type === 'double' ? 'двустворчатые ворота' : 'одна створка') +
        ', заготовка ' + need.stockLenM.toFixed(2) + ' м, пропил ' + need.kerfMm + ' мм' +
        ' <button class="calc-seg-del" onclick="calcClearGateImport(' + idx + ')">✕ убрать импорт</button></div>';

      if (Math.abs(need.stockLenM - DB.calcConfig.leafStockLength) > 0.001) {
        html += '<p class="calc-warn">⚠ Заготовка в импорте (' + need.stockLenM.toFixed(2) +
          ' м) отличается от «Заготовка (рамка калитки)» в настройках (' +
          DB.calcConfig.leafStockLength.toFixed(2) + ' м) — «в наличии» ниже считается для длины из импорта.</p>';
      }

      html += '<table class="calc-seg-table"><thead><tr><th>Деталь</th><th>Длина, м</th><th>Кол-во</th></tr></thead><tbody>';
      imp.pieces_per_leaf.forEach(function(p) {
        html += '<tr><td>' + p.label + '</td><td>' + (p.length_mm / 1000).toFixed(3) + '</td><td>' + p.qty + '</td></tr>';
      });
      html += '</tbody></table>';
      html += '<p class="calc-hint">Раскрой (пропил и укосины уже учтены программой gate_calc.html) — ' +
        (imp.type === 'double' ? 'на комплект (2 створки)' : 'на 1 створку') + '.</p>';

      var onHand = DB.calcConfig.leafStockOnHand || 0;
      var toBuy = Math.max(0, need.bars - onHand);
      var spare = Math.max(0, onHand - need.bars);
      html += '<div class="calc-summary">' +
        '<div class="calc-summary-item">нужно: <b>' + need.bars + '</b> шт. × ' + need.stockLenM.toFixed(2) + ' м</div>' +
        '<div class="calc-summary-item">в наличии: <b>' + onHand + '</b> шт.</div>' +
        (toBuy > 0
          ? '<div class="calc-summary-item calc-summary-buy">докупить: <b>' + toBuy + '</b> шт.</div>'
          : '<div class="calc-summary-item calc-summary-ok">хватает' + (spare > 0 ? ', в запасе <b>' + spare + '</b> шт.' : '') + '</div>') +
        '<div class="calc-summary-item">отход: <b>' + need.wasteM.toFixed(2) + '</b> м</div>' +
        '</div>';
    } else {
      html += '<table class="calc-seg-table"><thead><tr><th>Длина, м</th><th>Кол-во</th><th></th></tr></thead><tbody>';
      (g.segments || []).forEach(function(s, si) {
        html += '<tr>' +
          '<td><input type="number" min="0" step="0.01" value="' + s.length + '" ' +
          'onchange="calcUpdateGateSegment(' + idx + ',' + si + ',\'length\',this.value)"></td>' +
          '<td><input type="number" min="0" step="1" value="' + s.qty + '" ' +
          'onchange="calcUpdateGateSegment(' + idx + ',' + si + ',\'qty\',this.value)"></td>' +
          '<td><button class="calc-seg-del" onclick="calcRemoveGateSegment(' + idx + ',' + si + ')">✕</button></td>' +
          '</tr>';
      });
      html += '</tbody></table>';
      html += '<button class="calc-seg-add" onclick="calcAddGateSegment(' + idx + ')">➕ Добавить отрезок</button> ';
      html += '<label class="calc-import-btn">📥 Импортировать JSON' +
        '<input type="file" accept=".json,application/json" style="display:none" ' +
        'onchange="calcHandleGateFileInput(' + idx + ', this)"></label>';

      if (!r.specified) {
        html += '<p class="calc-warn">⚠ Размеры полотна не заданы (или не у всех отрезков указаны длина и количество) — материал на калитку не считается.</p>';
      } else {
        html += calcRenderPacked(r.packed, r.stockLen, DB.calcConfig.leafStockOnHand);
      }
    }
    html += '</div>';
  });

  el.innerHTML = html;
}

// ─── Полная перерисовка вкладки «Расчёт» ────────────────────────────────────
function calcRender() {
  var cfg = DB.calcConfig;

  var levelsInput = document.getElementById('calcLagLevels');
  var stockInput = document.getElementById('calcStockLength');
  var leafStockInput = document.getElementById('calcLeafStockLength');
  var stockOnHandInput = document.getElementById('calcStockOnHand');
  var leafStockOnHandInput = document.getElementById('calcLeafStockOnHand');
  if (levelsInput) levelsInput.value = cfg.lagLevels;
  if (stockInput) stockInput.value = cfg.stockLength;
  if (leafStockInput) leafStockInput.value = cfg.leafStockLength;
  if (stockOnHandInput) stockOnHandInput.value = cfg.stockOnHand;
  if (leafStockOnHandInput) leafStockOnHandInput.value = cfg.leafStockOnHand;

  var spansEl = document.getElementById('calcSpansTable');
  if (spansEl) spansEl.innerHTML = calcRenderSpansTable(calcGetSpans());

  var lagResult = calcLags();
  var lagOut = document.getElementById('calcLagResult');
  if (lagOut) {
    lagOut.innerHTML =
      '<div class="calc-block-title">Лаги по трассе (' + lagResult.levels + ' уровня, калитки исключены)</div>' +
      calcRenderPacked(lagResult.packed, lagResult.stockLen, cfg.stockOnHand);
  }

  calcRenderGates();
}

// ─── Обработчики полей ввода параметров расчёта ─────────────────────────────
function calcUpdateParam(field, value) {
  var n = parseFloat(value);
  var isOnHand = (field === 'stockOnHand' || field === 'leafStockOnHand');
  if (isNaN(n) || n < 0 || (!isOnHand && n <= 0)) return;
  if (field === 'lagLevels') n = Math.max(1, Math.round(n));
  if (isOnHand) n = Math.max(0, Math.round(n));
  DB.calcConfig[field] = n;
  calcRender();
}

// Перерисовать вкладку при переключении на неё (данные могли поменяться
// в редакторе опор на вкладке Профиль — dist пролётов пересчитается заново)
document.addEventListener('DOMContentLoaded', function() {
  var origSwitchTab = window.switchTab;
  if (typeof origSwitchTab === 'function') {
    window.switchTab = function(name) {
      origSwitchTab(name);
      if (name === 'calc') calcRender();
    };
  }
});
