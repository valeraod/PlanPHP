// editor.js — Редактор опор забора v4.12.4
// Зависит от: db.js (DB), utils.js (resolvePosts), plan.js (buildSVG), profile.js (buildProfile)

(function() {

  // Цепочка опор по порядку пути от опоры 1
  var CHAIN = ['1','13','12','11','10','9','2','5','6','17','7','8','4','15','16','3'];

  // Соседи в цепочке для каждой опоры
  var NEIGHBORS = {};
  for (var i = 0; i < CHAIN.length; i++) {
    NEIGHBORS[CHAIN[i]] = {
      left:  i > 0                 ? CHAIN[i - 1] : null,
      right: i < CHAIN.length - 1 ? CHAIN[i + 1] : null
    };
  }

  // Получить dist опоры по номеру
  function getDist(n) {
    var p = DB.fencePosts.filter(function(p){ return p.n === n; })[0];
    return p ? p.dist : 0;
  }

  // Определить side_fence по dist
  function getSideFence(dist) {
    if (dist <= 18.16) return 'vertical';
    if (dist <= 33.09) return 'horizontal';
    return 'perpendicular';
  }

  // Следующий свободный номер опоры
  function nextPostNum() {
    var used = DB.fencePosts.map(function(p){ return parseInt(p.n); }).filter(function(n){ return !isNaN(n); });
    var n = 1;
    while (used.indexOf(n) !== -1) n++;
    return String(n);
  }

  // Перестроить CHAIN и NEIGHBORS из DB.fencePosts по порядку dist
  function rebuildChain() {
    var sorted = DB.fencePosts.slice().sort(function(a,b){ return a.dist - b.dist; });
    CHAIN.length = 0;
    sorted.forEach(function(p){ CHAIN.push(p.n); });
    for (var i = 0; i < CHAIN.length; i++) {
      NEIGHBORS[CHAIN[i]] = {
        left:  i > 0                 ? CHAIN[i-1] : null,
        right: i < CHAIN.length - 1 ? CHAIN[i+1] : null
      };
    }
  }

  // Найти ключ сегмента по fromPost и toPost
  function findSegKey(from, to) {
    var segs = DB.redLineSegments;
    return Object.keys(segs).filter(function(k){
      return segs[k].fromPost === from && segs[k].toPost === to;
    })[0] || null;
  }

  // Следующий свободный ключ сегмента (буква)
  function nextSegKey() {
    var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var used = Object.keys(DB.redLineSegments);
    for (var i = 0; i < labels.length; i++) {
      if (used.indexOf(labels[i]) === -1) return labels[i];
    }
    return String(used.length + 1);
  }

  // Разбить сегмент L→R на L→N и N→R, наследуя зазор
  function splitSegment(leftN, newN, rightN) {
    var oldKey = findSegKey(leftN, rightN);
    var inheritVal = oldKey ? (window.redLineValues[oldKey] || DB.redLineDefaultCm) : DB.redLineDefaultCm;

    // Обновить существующий сегмент L→R → L→N
    if (oldKey) {
      DB.redLineSegments[oldKey].toPost = newN;
      DB.redLineSegments[oldKey].label = 'Линия ' + oldKey + ' (' + leftN + '→' + newN + ')';
      DB.redLineSegments[oldKey].anchorPost = leftN;
      window.redLineSegments[oldKey] = DB.redLineSegments[oldKey];
      window.redLineValues[oldKey] = inheritVal;
    }

    // Добавить новый сегмент N→R
    var newKey = nextSegKey();
    var newSeg = { label: 'Линия ' + newKey + ' (' + newN + '→' + rightN + ')', anchorPost: newN, fromPost: newN, toPost: rightN };
    DB.redLineSegments[newKey] = newSeg;
    DB.redLineDefaults[newKey] = inheritVal;
    window.redLineSegments[newKey] = newSeg;
    window.redLineValues[newKey] = inheritVal;
  }

  // Удалить сегмент X→right и расширить left→X до left→right
  function mergeSegments(leftN, delN, rightN) {
    var leftKey = findSegKey(leftN, delN);
    var rightKey = findSegKey(delN, rightN);

    // Расширить левый сегмент до rightN
    if (leftKey) {
      DB.redLineSegments[leftKey].toPost = rightN;
      DB.redLineSegments[leftKey].label = 'Линия ' + leftKey + ' (' + leftN + '→' + rightN + ')';
      window.redLineSegments[leftKey] = DB.redLineSegments[leftKey];
    }

    // Удалить правый сегмент
    if (rightKey) {
      delete DB.redLineSegments[rightKey];
      delete DB.redLineDefaults[rightKey];
      delete window.redLineSegments[rightKey];
      if (window.redLineValues) delete window.redLineValues[rightKey];
    }

    // Если текущий сегмент удалён — переключить на первый
    if (window.currentRedLine === rightKey) {
      window.currentRedLine = Object.keys(DB.redLineSegments)[0] || 'A';
    }
  }

  window.toggleEditor = function() {
    var sidebar = document.getElementById('editorSidebar');
    var btn = document.getElementById('btnEditor');
    var open = sidebar.classList.toggle('open');
    btn.classList.toggle('active', open);
    if (open) renderEditor();
  };

  function renderEditor() {
    var container = document.getElementById('editorBody');
    container.innerHTML = '';

    // Глобальный зазор
    var globalRow = document.createElement('div');
    globalRow.className = 'ed-global';
    globalRow.innerHTML =
      '<span class="ed-global-label">Зазор по умолч.:</span>' +
      '<input type="number" id="edDefaultGap" min="0" max="50" step="1" value="' + DB.redLineDefaultCm + '" class="ed-num" style="width:60px">' +
      '<span class="ed-unit">см</span>';
    container.appendChild(globalRow);

    // Заголовок таблицы
    var hdr = document.createElement('div');
    hdr.className = 'ed-header';
    hdr.innerHTML =
      '<span>№</span>' +
      '<span>Сосед</span>' +
      '<span style="text-align:right">Расст. м</span>' +
      '<span style="text-align:right">Глуб. м</span>';
    container.appendChild(hdr);

    // Строки опор в порядке цепочки
    CHAIN.forEach(function(n) {
      var post = DB.fencePosts.filter(function(p){ return p.n === n; })[0];
      if (!post) return;

      var row = document.createElement('div');
      row.className = 'ed-row';
      row.dataset.n = post.n;

      var nb = NEIGHBORS[post.n];
      var isFixed = post.fixed === true;

      if (isFixed) {
        // Фиксированная опора — только глубина редактируется
        var depthCell = '<input type="number" class="ed-num ed-depth" min="0.5" max="3" step="0.1" value="' + post.depth.toFixed(1) + '" data-n="' + post.n + '">';
        row.innerHTML =
          '<span class="ed-post-num">' + post.n + ' <span class="ed-anchor-tag" title="Фиксированная опора">⚓</span></span>' +
          '<span class="ed-fixed" style="text-align:center">—</span>' +
          '<span class="ed-fixed" style="text-align:right">' + post.dist.toFixed(2) + '</span>' +
          '<span>' + depthCell + '</span>';
      } else {
        // Подвижная опора
        // По умолчанию — левый сосед, стрелка →
        // dist отображается как расстояние от левого соседа
        var leftDist  = nb.left  ? getDist(nb.left)  : 0;
        var rightDist = nb.right ? getDist(nb.right) : 0;
        var defaultRef = 'left'; // по умолчанию — левый сосед
        var defaultDist = (post.dist - leftDist).toFixed(2);

        // Выпадающий список соседей
        var opts = '';
        if (nb.left)  opts += '<option value="left">'  + nb.left  + '</option>';
        if (nb.right) opts += '<option value="right">' + nb.right + '</option>';
        var neighborCell = '<select class="ed-select ed-neighbor" data-n="' + post.n + '">' + opts + '</select>';

        // Стрелка — отображается в зависимости от выбранного соседа
        var arrowCell = '<span class="ed-arrow" data-n="' + post.n + '">→</span>';

        // Расстояние
        var distCell = '<input type="number" class="ed-num ed-dist" min="0.20" max="20" step="0.01" value="' + defaultDist + '" data-n="' + post.n + '">';

        // Глубина
        var depthCell = '<input type="number" class="ed-num ed-depth" min="0.5" max="3" step="0.1" value="' + post.depth.toFixed(1) + '" data-n="' + post.n + '">';

        row.innerHTML =
          '<span class="ed-post-num">' + post.n + '</span>' +
          '<span>' + neighborCell + '</span>' +
          '<span>' + distCell + '</span>' +
          '<span>' + depthCell + '</span>';

        // При смене соседа — обновить расстояние
        var neighborEl = row.querySelector('.ed-neighbor');
        var distEl     = row.querySelector('.ed-dist');

        neighborEl.addEventListener('change', function() {
          var ref = neighborEl.value;
          var newVal  = ref === 'left'
            ? (post.dist - leftDist).toFixed(2)
            : (rightDist - post.dist).toFixed(2);
          distEl.value = newVal;
        });
      }

      container.appendChild(row);
    });

    // Кнопка Сохранить


    // === Блок удаления опоры ===
    var deleteRow = document.createElement('div');
    deleteRow.className = 'ed-align-row';

    var movableOptsD = CHAIN
      .map(function(n) { return DB.fencePosts.filter(function(p){ return p.n === n; })[0]; })
      .filter(function(p) { return p && !p.fixed; })
      .map(function(p) { return '<option value="' + p.n + '">' + p.n + '</option>'; })
      .join('');

    deleteRow.innerHTML =
      '<div class="ed-align-label">Удалить опору</div>' +
      '<div class="ed-align-controls">' +
        '<span>Опора </span>' +
        '<select id="edDeletePost">' + movableOptsD + '</select>' +
        '<button class="ed-align-btn ed-delete-btn" id="edDeleteBtn">Удалить</button>' +
      '</div>';
    container.appendChild(deleteRow);

    document.getElementById('edDeleteBtn').addEventListener('click', function() {
      var n = document.getElementById('edDeletePost').value;
      var post = DB.fencePosts.filter(function(p){ return p.n === n; })[0];
      if (!post) return;
      if (!confirm('Удалить опору ' + n + '?')) return;

      var nb = NEIGHBORS[n];
      var leftN  = nb.left;
      var rightN = nb.right;
      DB.fencePosts = DB.fencePosts.filter(function(p){ return p.n !== n; });
      rebuildChain();
      if (leftN && rightN) mergeSegments(leftN, n, rightN);
      buildSVG();
      buildProfile();
      renderEditor();
    });

    // === Блок вставки опоры ===
    var insertRow = document.createElement('div');
    insertRow.className = 'ed-align-row';

    var chainOpts = CHAIN.map(function(n){
      return '<option value="' + n + '">' + n + '</option>';
    }).join('');

    insertRow.innerHTML =
      '<div class="ed-align-label">Вставить опору</div>' +
      '<div class="ed-align-controls">' +
        '<span>Между </span>' +
        '<select id="edInsertLeft">' + chainOpts + '</select>' +
        '<span> и </span>' +
        '<select id="edInsertRight">' + chainOpts + '</select>' +
        '<button class="ed-align-btn" id="edInsertBtn">Вставить</button>' +
      '</div>';
    container.appendChild(insertRow);

    // По умолчанию правый = следующий за левым
    var insertLeftEl  = document.getElementById('edInsertLeft');
    var insertRightEl = document.getElementById('edInsertRight');
    insertLeftEl.addEventListener('change', function() {
      var idx = CHAIN.indexOf(insertLeftEl.value);
      if (idx >= 0 && idx < CHAIN.length - 1) {
        insertRightEl.value = CHAIN[idx + 1];
      }
    });
    // Инициализация
    if (CHAIN.length > 1) {
      insertLeftEl.value  = CHAIN[0];
      insertRightEl.value = CHAIN[1];
    }

    document.getElementById('edInsertBtn').addEventListener('click', function() {
      var leftN  = insertLeftEl.value;
      var rightN = insertRightEl.value;
      var leftPost  = DB.fencePosts.filter(function(p){ return p.n === leftN; })[0];
      var rightPost = DB.fencePosts.filter(function(p){ return p.n === rightN; })[0];
      if (!leftPost || !rightPost) { alert('Опоры не найдены'); return; }
      if (leftPost.dist >= rightPost.dist) { alert('Левая опора должна быть левее правой'); return; }

      var newDist  = leftPost.dist + (rightPost.dist - leftPost.dist) / 2;
      var newN     = nextPostNum();
      var newPost  = {
        n:          newN,
        dist:       Math.round(newDist * 100) / 100,
        fixed:      false,
        depth:      leftPost.depth,
        side_fence: getSideFence(newDist),
        info:       'Опора ' + newN
      };

      DB.fencePosts.push(newPost);
      rebuildChain();
      splitSegment(leftN, newN, rightN);
      buildSVG();
      buildProfile();
      renderEditor();
    });

    // === Блок выравнивания ===
    var alignRow = document.createElement('div');
    alignRow.className = 'ed-align-row';

    // Список подвижных опор
    var movableOpts = CHAIN
      .map(function(n) { return DB.fencePosts.filter(function(p){ return p.n === n; })[0]; })
      .filter(function(p) { return p && !p.fixed; })
      .map(function(p) { return '<option value="' + p.n + '">' + p.n + '</option>'; })
      .join('');

    alignRow.innerHTML =
      '<div class="ed-align-label">Выровнять</div>' +
      '<div class="ed-align-controls">' +
        '<span>Опора </span>' +
        '<select id="edAlignPost">' + movableOpts + '</select>' +
        '<span> относительно </span>' +
        '<select id="edAlignRef">' +
          '<option value="left">левого соседа</option>' +
          '<option value="right">правого соседа</option>' +
        '</select>' +
        '<select id="edAlignMode">' +
          '<option value="top">по верху</option>' +
          '<option value="bottom">по низу</option>' +
        '</select>' +
        '<button class="ed-align-btn" id="edAlignBtn">Выровнять</button>' +
      '</div>';

    container.appendChild(alignRow);

    document.getElementById('edAlignBtn').addEventListener('click', function() {
      var n    = document.getElementById('edAlignPost').value;
      var ref  = document.getElementById('edAlignRef').value;
      var mode = document.getElementById('edAlignMode').value;

      var post = DB.fencePosts.filter(function(p){ return p.n === n; })[0];
      if (!post) return;

      var nb      = NEIGHBORS[n];
      var refN    = ref === 'left' ? nb.left : nb.right;
      if (!refN) { alert('Нет соседа с этой стороны'); return; }
      var refPost = DB.fencePosts.filter(function(p){ return p.n === refN; })[0];
      if (!refPost) return;

      // Высота рельефа под каждой опорой
      var hX   = interpH(post.dist);
      var hRef = interpH(refPost.dist);

      // Верх опоры = высота рельефа + (postLength - depth)
      // Низ опоры  = высота рельефа - depth (уходит в землю)
      // Выравниваем: topX = topRef  → (hX + postLength - depthX) = (hRef + postLength - depthRef)
      //              → depthX = depthRef + hX - hRef
      // По низу:    botX = botRef  → (hX - depthX) = (hRef - depthRef)
      //              → depthX = depthRef - hRef + hX = depthRef + hX - hRef
      // Формула одинакова! Разница в знаке hRef-hX относительно системы координат.

      var newDepth;
      if (mode === 'top') {
        // topX = topRef: hX + (L - depthX) = hRef + (L - depthRef)
        // depthX = depthRef + hX - hRef
        newDepth = refPost.depth + hX - hRef;
      } else {
        // botX = botRef: hX - depthX = hRef - depthRef
        // depthX = depthRef - hRef + hX
        newDepth = refPost.depth - hRef + hX;
      }

      newDepth = Math.round(newDepth * 100) / 100;

      if (newDepth < 0.5 || newDepth > 3.0) {
        alert('Вычисленная глубина ' + newDepth.toFixed(2) + ' м вне допустимого диапазона 0.5–3.0 м');
        return;
      }

      // Записать в базу и обновить поле в таблице
      post.depth = newDepth;
      var depthEl = container.querySelector('.ed-row[data-n="' + n + '"] .ed-depth');
      if (depthEl) depthEl.value = newDepth.toFixed(1);

      buildSVG();
      buildProfile();
    });

    var saveRow = document.createElement('div');
    saveRow.className = 'ed-save-row';
    saveRow.innerHTML = '<button class="ed-save-btn" id="edSaveBtn">💾 Сохранить</button>';
    container.appendChild(saveRow);

    document.getElementById('edSaveBtn').addEventListener('click', function() {
      // Глобальный зазор
      var gapEl = document.getElementById('edDefaultGap');
      if (gapEl) DB.redLineDefaultCm = Number(gapEl.value);

      var MIN_DIST = 0.20;
      var errors = [];
      var newDists = {};

      // Собрать новые dist
      container.querySelectorAll('.ed-row').forEach(function(row) {
        var n = row.dataset.n;
        var post = DB.fencePosts.filter(function(p){ return p.n === n; })[0];
        if (!post) return;

        if (post.fixed) {
          newDists[n] = post.dist;
          return;
        }

        var neighborEl = row.querySelector('.ed-neighbor');
        var distEl     = row.querySelector('.ed-dist');
        var depthEl    = row.querySelector('.ed-depth');
        var ref        = neighborEl ? neighborEl.value : 'left';
        var val        = parseFloat(distEl.value) || 0;
        var nb         = NEIGHBORS[n];

        var refPost = DB.fencePosts.filter(function(p){ return p.n === (ref === 'left' ? nb.left : nb.right); })[0];
        var refDist = refPost ? refPost.dist : 0;

        newDists[n] = ref === 'left' ? refDist + val : refDist - val;
      });

      // Валидация — соседи в цепочке не ближе MIN_DIST
      for (var i = 0; i < CHAIN.length - 1; i++) {
        var nA = CHAIN[i], nB = CHAIN[i + 1];
        if (newDists[nA] === undefined || newDists[nB] === undefined) continue;
        var gap = newDists[nB] - newDists[nA];
        if (gap < MIN_DIST) {
          errors.push({ n: nB, msg: 'Опора ' + nB + ': расстояние до ' + nA + ' = ' + (gap * 100).toFixed(0) + ' см < 20 см' });
        }
      }

      // Сбросить подсветку
      container.querySelectorAll('.ed-row').forEach(function(row) { row.classList.remove('ed-row-error'); });
      var errMsg = container.querySelector('.ed-error-msg');
      if (errMsg) errMsg.remove();

      if (errors.length > 0) {
        errors.forEach(function(e) {
          var row = container.querySelector('.ed-row[data-n="' + e.n + '"]');
          if (row) row.classList.add('ed-row-error');
        });
        var msg = document.createElement('div');
        msg.className = 'ed-error-msg';
        msg.innerHTML = '⚠ Не сохранено:<br>' + errors.map(function(e){ return e.msg; }).join('<br>');
        container.querySelector('.ed-save-row').before(msg);
        return;
      }

      // Применить depth и новые dist
      container.querySelectorAll('.ed-row').forEach(function(row) {
        var n = row.dataset.n;
        var post = DB.fencePosts.filter(function(p){ return p.n === n; })[0];
        if (!post) return;
        var depthEl = row.querySelector('.ed-depth');
        if (depthEl) post.depth = parseFloat(depthEl.value) || post.depth;
        if (!post.fixed && newDists[n] !== undefined) post.dist = newDists[n];
      });

      buildSVG();
      buildProfile();
      renderEditor();
    });
  }

})();
