// plan.js — построение вида сверху (план)
// Версия v4.12.9
// Зависит от: db.js (DB), utils.js (px, cx, cy, pt, el, addLabel, dimH, dimV)

// ─── Состояние зума плана ────────────────────────────────────────────────────
var currentZoom = 1.0;
var baseSvgW = 0, baseSvgH = 0;

function setZoom(z) {
  currentZoom = Math.max(0.3, Math.min(5.0, z));
  var svg = document.getElementById('mainSvg');
  if (!baseSvgW) {
    var vb = svg.getAttribute('viewBox').split(' ');
    baseSvgW = parseFloat(vb[2]);
    baseSvgH = parseFloat(vb[3]);
  }
  svg.setAttribute('width',  baseSvgW * currentZoom);
  svg.setAttribute('height', baseSvgH * currentZoom);
  document.getElementById('zoomInfo').textContent = currentZoom.toFixed(1) + '×';
}

// ─── Экспорт плана ───────────────────────────────────────────────────────────
function exportSVG() {
  var svg = document.getElementById('mainSvg');
  var clone = svg.cloneNode(true);
  clone.style.transform = '';
  var bg = document.createElementNS('http://www.w3.org/2000/svg','rect');
  bg.setAttribute('width','100%'); bg.setAttribute('height','100%'); bg.setAttribute('fill','#ffffff');
  clone.insertBefore(bg, clone.firstChild);
  var data = new XMLSerializer().serializeToString(clone);
  var blob = new Blob([data], { type:'image/svg+xml' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'plan_uchastka.svg';
  a.click();
}

// ─── Легенда плана ───────────────────────────────────────────────────────────
function toggleLegend() {
  var l = document.getElementById('legend');
  var b = document.getElementById('btnLegend');
  if (l.style.display === 'none') {
    l.style.display = 'block';
    b.classList.add('active');
  } else {
    l.style.display = 'none';
    b.classList.remove('active');
  }
}

// ─── Вспомогательные функции плана ──────────────────────────────────────────
function showTip(e, p) {
  var t = document.getElementById('tooltip');
  t.innerHTML = '<b style="color:#e94560">' + p.n + '</b><br>' + p.info + '<br><span style="color:#888">x=' + p.xm.toFixed(2) + 'м, y=' + p.ym.toFixed(2) + 'м</span>';
  t.style.display = 'block';
  t.style.left = (e.clientX + 12) + 'px';
  t.style.top  = (e.clientY - 10) + 'px';
}
function hideTip() { document.getElementById('tooltip').style.display = 'none'; }

function scaleBar(svg, sx, sy) {
  for (var i = 0; i < 5; i++) {
    svg.appendChild(el('rect', { x:sx+i*DB.SCALE, y:sy-6, width:DB.SCALE, height:6, fill: i%2===0?'#ffffff':'#999999', stroke:'#000', 'stroke-width':'0.5' }));
  }
  svg.appendChild(el('rect', { x:sx, y:sy-6, width:DB.SCALE*5, height:6, fill:'none', stroke:'#000', 'stroke-width':'1' }));
  for (var j = 0; j <= 5; j++) {
    addLabel(svg, sx+j*DB.SCALE, sy+10, j+'м', '#000', 9);
  }
}

function compass(svg, cx, cy) {
  var R = 36;
  svg.appendChild(el('circle', { cx:cx, cy:cy, r:R+6, fill:'#f5f5f5', stroke:'#ccc', 'stroke-width':'1', opacity:'0.92' }));

  var dirs = [
    { label:'С', angle: 90,  color:'#c00' },
    { label:'В', angle: 180, color:'#000' },
    { label:'Ю', angle: 270, color:'#000' },
    { label:'З', angle: 0,   color:'#000' }
  ];

  function rad(deg) { return deg * Math.PI / 180; }

  [45,135,225,315].forEach(function(a) {
    var r1 = R - 4, r2 = R;
    svg.appendChild(el('line', {
      x1: cx + r1 * Math.sin(rad(a)), y1: cy - r1 * Math.cos(rad(a)),
      x2: cx + r2 * Math.sin(rad(a)), y2: cy - r2 * Math.cos(rad(a)),
      stroke:'#000', 'stroke-width':'1'
    }));
  });

  dirs.forEach(function(d) {
    var a = rad(d.angle);
    var tipX  = cx + (R - 2) * Math.sin(a);
    var tipY  = cy - (R - 2) * Math.cos(a);
    var baseX = cx - 6 * Math.sin(a);
    var baseY = cy + 6 * Math.cos(a);
    var perpX = 5 * Math.cos(a);
    var perpY = 5 * Math.sin(a);

    var fillMain  = d.label === 'С' ? '#c00' : '#000';
    var fillLight = d.label === 'С' ? '#e88' : '#000';

    var pathL = 'M'+tipX+','+tipY+' L'+(baseX-perpX)+','+(baseY-perpY)+' L'+cx+','+cy+'Z';
    svg.appendChild(el('path', { d:pathL, fill:fillMain, opacity:'0.9' }));
    var pathR = 'M'+tipX+','+tipY+' L'+(baseX+perpX)+','+(baseY+perpY)+' L'+cx+','+cy+'Z';
    svg.appendChild(el('path', { d:pathR, fill:fillLight, opacity:'0.9' }));

    var lx = cx + (R + 13) * Math.sin(a);
    var ly = cy - (R + 13) * Math.cos(a);
    svg.appendChild(el('text', {
      x: lx, y: ly,
      'text-anchor':'middle', 'dominant-baseline':'middle',
      fill: d.label === 'С' ? '#c00' : '#000',
      'font-size': d.label === 'С' ? '13' : '11',
      'font-family':'Courier New', 'font-weight':'bold'
    })).textContent = d.label;
  });

  svg.appendChild(el('circle', { cx:cx, cy:cy, r:3, fill:'#000' }));
}

function brickWall(svg, x1, y1, x2, y2, dir) {
  var W = 8;
  var rx, ry, rw, rh;
  if (dir === 'h') { rx = Math.min(x1,x2); ry = y1-W/2; rw = Math.abs(x2-x1); rh = W; }
  else             { rx = x1-W/2; ry = Math.min(y1,y2); rw = W; rh = Math.abs(y2-y1); }
  svg.appendChild(el('rect', { x:rx, y:ry, width:rw, height:rh, fill:'url(#brick)', stroke:'#BA7517', 'stroke-width':'1.5', opacity:'0.9' }));
}

function drawPoint(svg, p) {
  var px2 = cx(p.xm), py2 = cy(p.ym);
  var g = el('g', {});
  g.style.cursor = 'pointer';

  if (p.t === 'post_a') {
    g.appendChild(el('rect', { x:px2-7, y:py2-7, width:14, height:14, rx:2, fill:'#0f3460', stroke:'#4a9eff', 'stroke-width':'2' }));
    var t = el('text', { x:px2, y:py2+1, 'text-anchor':'middle', 'dominant-baseline':'middle', fill:'#4a9eff', 'font-size':'9', 'font-family':'Courier New', 'font-weight':'bold' });
    t.textContent = p.n; g.appendChild(t);
  } else if (p.t === 'post') {
    g.appendChild(el('rect', { x:px2-7, y:py2-7, width:14, height:14, rx:2, fill:'#1a1a2e', stroke:'#e94560', 'stroke-width':'2' }));
    var t2 = el('text', { x:px2, y:py2+1, 'text-anchor':'middle', 'dominant-baseline':'middle', fill:'#e94560', 'font-size':'9', 'font-family':'Courier New', 'font-weight':'bold' });
    t2.textContent = p.n; g.appendChild(t2);
  } else if (p.t === 'wall_corner') {
    g.appendChild(el('circle', { cx:px2, cy:py2, r:5, fill:'#BA7517' }));
  } else if (p.t === 'entry') {
    g.appendChild(el('circle', { cx:px2, cy:py2, r:5, fill:'#4a9eff' }));
  } else if (p.t === 'fence_corner') {
    g.appendChild(el('rect', { x:px2-7, y:py2-7, width:14, height:14, rx:2, fill:'#3d2e00', stroke:'#7a5c00', 'stroke-width':'2' }));
    var tfc = el('text', { x:px2, y:py2+1, 'text-anchor':'middle', 'dominant-baseline':'middle', fill:'#e8c468', 'font-size':'9', 'font-family':'Courier New', 'font-weight':'bold' });
    tfc.textContent = p.n; g.appendChild(tfc);
  } else if (p.t === 'fence_post') {
    g.appendChild(el('circle', { cx:px2, cy:py2, r:6, fill:'#fff', stroke:'#7a5c00', 'stroke-width':'2' }));
    var tfp = el('text', { x:px2, y:py2, 'text-anchor':'middle', 'dominant-baseline':'central', fill:'#7a5c00', 'font-size':'8', 'font-family':'Courier New', 'font-weight':'bold' });
    tfp.textContent = p.n; g.appendChild(tfp);
  } else {
    g.appendChild(el('circle', { cx:px2, cy:py2, r:4, fill:'#000' }));
  }

  var lx = px2 + 10, ly = py2 - 8, anchor = 'start';
  if (p.side_fence === 'vertical') {
    lx = px2 - 10; ly = py2 + 4; anchor = 'end';
  } else if (p.side_fence === 'horizontal') {
    lx = px2; ly = py2 + 22; anchor = 'middle';
  }
  var lbl = el('text', { x:lx, y:ly, 'text-anchor':anchor, fill:'#222', 'font-size':'11', 'font-family':'Courier New', 'font-weight':'bold' });
  lbl.textContent = p.n; g.appendChild(lbl);
  if (p.h) {
    var hl = el('text', { x:lx, y:ly+12, fill:'#000', 'font-size':'9', 'font-family':'Courier New' });
    hl.textContent = 'h=' + p.h; g.appendChild(hl);
  }

  g.addEventListener('mouseenter', function(e) { showTip(e, p); });
  g.addEventListener('mouseleave', function() { hideTip(); });
  g.addEventListener('touchstart', function(e) { e.preventDefault(); showTip(e.touches[0], p); });
  g.addEventListener('touchend', function() { setTimeout(hideTip, 1500); });
  svg.appendChild(g);
}

// ─── Построение плана ────────────────────────────────────────────────────────
function buildSVG() {
  baseSvgW = 0; baseSvgH = 0; // сброс при перестройке
  var margin = 80;
  var allX = DB.points.map(function(p){ return cx(p.xm); });
  var allY = DB.points.map(function(p){ return cy(p.ym); });
  var W = Math.max.apply(null, allX) + margin;
  var H = Math.max.apply(null, allY) + margin + px(0.4) + 20; // + запас под вынос забора вниз и подписи

  var svg = document.getElementById('mainSvg');
  svg.setAttribute('width', W);
  svg.setAttribute('height', H);
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
  svg.innerHTML = '';

  // Defs
  var defs = el('defs', {});
  var pat = el('pattern', { id:'brick', patternUnits:'userSpaceOnUse', width:'20', height:'10' });
  pat.appendChild(el('rect', { width:'20', height:'10', fill:'none', stroke:'#BA7517', 'stroke-width':'0.4', opacity:'0.5' }));
  pat.appendChild(el('rect', { x:'0', y:'0', width:'10', height:'5', fill:'none', stroke:'#BA7517', 'stroke-width':'0.4', opacity:'0.5' }));
  pat.appendChild(el('rect', { x:'10', y:'5', width:'10', height:'5', fill:'none', stroke:'#BA7517', 'stroke-width':'0.4', opacity:'0.5' }));
  defs.appendChild(pat);
  var marker = el('marker', { id:'arr', viewBox:'0 0 10 10', refX:'8', refY:'5', markerWidth:'5', markerHeight:'5', orient:'auto' });
  marker.appendChild(el('path', { d:'M2 2L8 5L2 8', fill:'none', stroke:'#BA7517', 'stroke-width':'1.5', 'stroke-linecap':'round' }));
  defs.appendChild(marker);
  svg.appendChild(defs);

  // Сетка
  var gridG = el('g', { opacity:'0.12' });
  for (var i = 0; i < W; i += DB.SCALE) gridG.appendChild(el('line', { x1:i, y1:0, x2:i, y2:H, stroke:'#ccc', 'stroke-width':'0.5' }));
  for (var j = 0; j < H; j += DB.SCALE) gridG.appendChild(el('line', { x1:0, y1:j, x2:W, y2:j, stroke:'#ccc', 'stroke-width':'0.5' }));
  svg.appendChild(gridG);

  // Каменная стена А–Б
  svg.appendChild(el('line', { x1:pt('А').px, y1:pt('А').py, x2:pt('Б').px, y2:pt('Б').py, stroke:'#000', 'stroke-width':'5', 'stroke-linecap':'round' }));
  addLabel(svg, (pt('А').px+pt('Б').px)/2, pt('А').py-12, '7,92 м', '#000', 9);

  // Газовая труба
  var pipe = [['В','Г'],['Г','Д'],['Д','Е'],['Е','Ж'],['Ж','З'],['З','И'],['И','К']];
  pipe.forEach(function(ab) {
    var A = pt(ab[0]), B = pt(ab[1]);
    svg.appendChild(el('line', { x1:A.px, y1:A.py, x2:B.px, y2:B.py, stroke:'#e94560', 'stroke-width':'2', 'stroke-dasharray':'8 4' }));
  });

  // Линия забора — сдвиг 0,4м влево (X-) и 0,4м вниз (Y+) от каждой точки трубы
  var FENCE_OFFSET = DB.FENCE_OFFSET;
  var fenceOrder = ['В','Г','Д','Е','Ж','З','И','К'];
  var fencePts = fenceOrder.map(function(n) {
    var p = pt(n);
    return { x: cx(p.xm - FENCE_OFFSET), y: cy(p.ym + FENCE_OFFSET) };
  });
  var fenceD = 'M' + fencePts.map(function(fp){ return fp.x + ',' + fp.y; }).join(' L');
  svg.appendChild(el('path', { d: fenceD, fill:'none', stroke:'#7a5c00', 'stroke-width':'2', 'stroke-dasharray':'2 3' }));
  addLabel(svg, fencePts[0].x - 36, fencePts[0].y - 10, '0,4м', '#7a5c00', 9);
  addLabel(svg, fencePts[fencePts.length-1].x, fencePts[fencePts.length-1].y + 18, 'Забор (0,4м от трубы)', '#7a5c00', 9);

  // Перпендикуляр от Р до линии забора
  var rXm = DB.points.filter(function(p){ return p.n==='Р'; })[0].xm;
  var rYm = DB.points.filter(function(p){ return p.n==='Р'; })[0].ym;
  var fenceLineYm = 18.16 + FENCE_OFFSET;
  svg.appendChild(el('line', {
    x1: cx(rXm), y1: cy(rYm), x2: cx(rXm), y2: cy(fenceLineYm),
    stroke:'#7a5c00', 'stroke-width':'1.2', 'stroke-dasharray':'5 3'
  }));
  addLabel(svg, cx(rXm)+30, (cy(rYm)+cy(fenceLineYm))/2, (fenceLineYm-rYm).toFixed(2)+'м', '#7a5c00', 9);

  // Опоры забора — из DB.fencePosts через resolvePosts()
  var cornerSet = { '2': true, '4': true };
  var postCoords = resolvePosts();
  var fencePosts = DB.fencePosts.map(function(p) {
    var c = postCoords[p.n] || { xm: 0, ym: 0 };
    return { n: p.n, xm: c.xm, ym: c.ym, t: cornerSet[p.n] ? 'fence_corner' : 'fence_post', h: '', info: p.info, side_fence: p.side_fence };
  });
  fencePosts.forEach(function(p) { drawPoint(svg, p); });

  // Стена дома
  brickWall(svg, pt('Б').px, pt('Б').py, pt('Л').px, pt('Л').py, 'v');
  dimV(svg, pt('Б').px+16, pt('Б').py, pt('Л').py, '9,70 м');
  brickWall(svg, pt('М').px, pt('Л').py, pt('Л').px, pt('Л').py, 'h');
  dimH(svg, pt('М').px, pt('Л').px, pt('Л').py-16, '1,58 м', '#000');
  brickWall(svg, pt('М').px, pt('М').py, pt('Н').px, pt('Н').py, 'v');
  dimV(svg, pt('М').px-20, pt('М').py, pt('Н').py, '5,14 м');
  brickWall(svg, pt('Н').px, pt('Н').py, pt('О').px, pt('О').py, 'h');
  dimH(svg, pt('Н').px, pt('О').px, pt('Н').py-16, '3,83 м', '#000');

  // Проём
  svg.appendChild(el('line', { x1:pt('О').px, y1:pt('О').py, x2:pt('П').px, y2:pt('П').py, stroke:'#4a9eff', 'stroke-width':'2', 'stroke-dasharray':'6 3' }));
  dimH(svg, pt('О').px, pt('П').px, pt('О').py+22, 'вход 2,27 м', '#4a9eff');

  brickWall(svg, pt('П').px, pt('П').py, pt('Р').px, pt('Р').py, 'h');
  dimH(svg, pt('П').px, pt('Р').px, pt('П').py-16, '2,26 м', '#000');

  // Продолжение стены
  svg.appendChild(el('line', { x1:pt('Р').px, y1:pt('Р').py, x2:pt('Р').px+40, y2:pt('Р').py, stroke:'#BA7517', 'stroke-width':'2', 'stroke-dasharray':'4 3', 'marker-end':'url(#arr)' }));
  addLabel(svg, pt('Р').px+50, pt('Р').py+4, '→', '#BA7517', 10);

  // Все точки
  DB.points.forEach(function(p) { drawPoint(svg, p); });

  // Синяя линия
  var lineX = cx(14.70 + 15.55);
  svg.appendChild(el('line', { x1:lineX, y1:0, x2:lineX, y2:H, stroke:'#2196F3', 'stroke-width':'1.5', 'stroke-dasharray':'8 4', opacity:'0.7' }));
  addLabel(svg, lineX+5, 20, '← 15,55м от Р', '#2196F3', 9);

  // Масштабная линейка
  scaleBar(svg, DB.OX, H - 30);

  // Компас
  compass(svg, W - 70, 70);
}

// ─── Инициализация: зум и drag для плана ────────────────────────────────────
document.getElementById('canvasWrap').addEventListener('wheel', function(e) {
  e.preventDefault();
  var factor = e.deltaY > 0 ? -0.1 : 0.1;
  setZoom(currentZoom + factor);
}, { passive: false });

(function() {
  var wrap = document.getElementById('canvasWrap');
  var dragging = false, startX, startY, scrollLeft, scrollTop;
  wrap.addEventListener('mousedown', function(e) {
    if (e.button !== 0) return;
    dragging = true;
    startX = e.clientX; startY = e.clientY;
    scrollLeft = wrap.scrollLeft; scrollTop = wrap.scrollTop;
    wrap.style.userSelect = 'none';
  });
  window.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    wrap.scrollLeft = scrollLeft - (e.clientX - startX);
    wrap.scrollTop  = scrollTop  - (e.clientY - startY);
  });
  window.addEventListener('mouseup', function() {
    dragging = false;
    wrap.style.userSelect = '';
  });
})();
